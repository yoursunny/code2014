#include "syscall.h"

void t3() {
    int i;
    SetPriority(60);
    for (i=0;i<3000;++i);
    SetPriority(200);
    for (i=0;i<3000;++i);
    ThreadExit(233);
}

void t1() {
    int i;
    ThreadFork((void*)t3);
    for (i=0;i<600;++i) {
        if (i%50==0) ThreadYield();
    }
    ThreadExit(111);
}

void t2() {
    int i;
    for (i=0;i<800;++i) if (i%100==0) Clock();
    ThreadExit(22);
}

void last() {
    int i;
    SetPriority(255);
    ThreadYield();
    for (i=0;i<10000;++i);
    Halt();
}

int main() {
    int i;
    ThreadFork((void*)last);
    for (i=0;i<1000;++i);
    ThreadFork((void*)t1);
    for (i=0;i<1000;++i);
    ThreadFork((void*)t2);
    for (i=0;i<100;++i);
    ThreadExit(64);
}
