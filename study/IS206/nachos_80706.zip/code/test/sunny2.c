#include "syscall.h"

int a[100];
int i=1;

int main() {
    for (i=0;i<100;i+=20) {
        a[i]=i;
        a[i+5];
    }
    for (i=0;i<100;i+=20) {
        a[i+1]=Add(a[i],35-2*i);
    }
    Halt();
}
