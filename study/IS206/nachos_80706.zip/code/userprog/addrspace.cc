// addrspace.cc
//	Routines to manage address spaces (executing user programs).
//
//	In order to run a user program, you must:
//
//	1. link with the -n -T 0 option
//	2. run coff2noff to convert the object file to Nachos format
//		(Nachos object code format is essentially just a simpler
//		version of the UNIX executable object code format)
//	3. load the NOFF file into the Nachos file system
//		(if you are using the "stub" file system, you
//		don't need to do this last step)
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "main.h"
#include "addrspace.h"
#include "machine.h"
#include "noff.h"

#ifdef VIRTMEM
#include <stdio.h>
#endif

//----------------------------------------------------------------------
// SwapHeader
// 	Do little endian to big endian conversion on the bytes in the
//	object file header, in case the file was generated on a little
//	endian machine, and we're now running on a big endian machine.
//----------------------------------------------------------------------

static void
SwapHeader (NoffHeader *noffH)
{
    noffH->noffMagic = WordToHost(noffH->noffMagic);
    noffH->code.size = WordToHost(noffH->code.size);
    noffH->code.virtualAddr = WordToHost(noffH->code.virtualAddr);
    noffH->code.inFileAddr = WordToHost(noffH->code.inFileAddr);
#ifdef RDATA
    noffH->readonlyData.size = WordToHost(noffH->readonlyData.size);
    noffH->readonlyData.virtualAddr =
           WordToHost(noffH->readonlyData.virtualAddr);
    noffH->readonlyData.inFileAddr =
           WordToHost(noffH->readonlyData.inFileAddr);
#endif
    noffH->initData.size = WordToHost(noffH->initData.size);
    noffH->initData.virtualAddr = WordToHost(noffH->initData.virtualAddr);
    noffH->initData.inFileAddr = WordToHost(noffH->initData.inFileAddr);
    noffH->uninitData.size = WordToHost(noffH->uninitData.size);
    noffH->uninitData.virtualAddr = WordToHost(noffH->uninitData.virtualAddr);
    noffH->uninitData.inFileAddr = WordToHost(noffH->uninitData.inFileAddr);

#ifdef RDATA
    DEBUG(dbgAddr, "code = " << noffH->code.size <<
                   " readonly = " << noffH->readonlyData.size <<
                   " init = " << noffH->initData.size <<
                   " uninit = " << noffH->uninitData.size << "\n");
#endif
}

//----------------------------------------------------------------------
// AddrSpace::AddrSpace
// 	Create an address space to run a user program.
//	Set up the translation from program memory to physical
//	memory.  For now, this is really simple (1:1), since we are
//	only uniprogramming, and we have a single unsegmented page table
//----------------------------------------------------------------------

AddrSpace::AddrSpace()
{
    #ifndef VIRTMEM
    pageTable = new TranslationEntry[NumPhysPages];
    for (int i = 0; i < NumPhysPages; i++) {
	pageTable[i].virtualPage = i;	// for now, virt page # = phys page #
	pageTable[i].physicalPage = i;
	pageTable[i].valid = TRUE;
	pageTable[i].use = FALSE;
	pageTable[i].dirty = FALSE;
	pageTable[i].readOnly = FALSE;
    }
    #endif
    #ifdef VIRTMEM
    pageTable = new TranslationEntry[NumVirtualPages];
    for (int i = 0; i < NumVirtualPages; i++) {
	pageTable[i].virtualPage = i;
	pageTable[i].valid = FALSE;
    }
    #endif

    #ifndef VIRTMEM
    // zero out the entire address space
    bzero(kernel->machine->mainMemory, MemorySize);
    #endif
    #ifdef VIRTMEM
    this->pageInfo=new VirtMemPageInfo[NumVirtualPages];
    this->allocator=new VirtMemMRAllocator(this->pageTable);
    this->swapStatus=new VirtMemPageInfo*[NumSwapPages];
    #endif
}

//----------------------------------------------------------------------
// AddrSpace::~AddrSpace
// 	Dealloate an address space.
//----------------------------------------------------------------------

AddrSpace::~AddrSpace()
{
   delete pageTable;
    #ifdef VIRTMEM
    delete this->pageInfo;
    delete this->allocator;
    delete this->executable;
    if (this->swapFileName) delete this->swapFileName;
    if (this->swapArea) delete this->swapArea;
    #endif
}


//----------------------------------------------------------------------
// AddrSpace::Load
// 	Load a user program into memory from a file.
//
//	Assumes that the page table has been initialized, and that
//	the object code file is in NOFF format.
//
//	"fileName" is the file containing the object code to load into memory
//----------------------------------------------------------------------

bool
AddrSpace::Load(char *fileName)
{
    OpenFile *executable = kernel->fileSystem->Open(fileName);
    NoffHeader noffH;
    unsigned int size;

    if (executable == NULL) {
	cerr << "Unable to open file " << fileName << "\n";
	return FALSE;
    }

    executable->ReadAt((char *)&noffH, sizeof(noffH), 0);
    if ((noffH.noffMagic != NOFFMAGIC) &&
		(WordToHost(noffH.noffMagic) == NOFFMAGIC))
    	SwapHeader(&noffH);
    ASSERT(noffH.noffMagic == NOFFMAGIC);

#ifdef RDATA
// how big is address space?
    size = noffH.code.size + noffH.readonlyData.size + noffH.initData.size +
           noffH.uninitData.size + UserStackSize;
                                                // we need to increase the size
						// to leave room for the stack
#else
// how big is address space?
    size = noffH.code.size + noffH.initData.size + noffH.uninitData.size
			+ UserStackSize;	// we need to increase the size
						// to leave room for the stack
#endif
    numPages = divRoundUp(size, PageSize);
    size = numPages * PageSize;

    #ifndef VIRTMEM
    ASSERT(numPages <= NumPhysPages);		// check we're not trying
						// to run anything too big --
						// at least until we have
						// virtual memory
    #endif
    #ifdef VIRTMEM
    ASSERT(numPages <= NumVirtualPages);
    #endif

    DEBUG(dbgAddr, "Initializing address space: " << numPages << ", " << size);

// then, copy in the code and data segments into memory
// Note: this code assumes that virtual address = physical address
    if (noffH.code.size > 0) {
        DEBUG(dbgAddr, "Initializing code segment.");
    #ifndef VIRTMEM
	DEBUG(dbgAddr, noffH.code.virtualAddr << ", " << noffH.code.size);
        executable->ReadAt(
		&(kernel->machine->mainMemory[noffH.code.virtualAddr]),
			noffH.code.size, noffH.code.inFileAddr);
    #endif
    #ifdef VIRTMEM
    int startPage=divRoundDown(noffH.code.virtualAddr,PageSize);
    int endPage=divRoundDown(noffH.code.virtualAddr+noffH.code.size-1,PageSize);
    for (int i=startPage;i<=endPage;++i) {
        this->pageInfo[i].status=(this->pageInfo[i].status!=vmpsInvalid)?vmpsMixed:vmpsCode;
    }
    #endif
    }
    if (noffH.initData.size > 0) {
        DEBUG(dbgAddr, "Initializing data segment.");
    #ifndef VIRTMEM
	DEBUG(dbgAddr, noffH.initData.virtualAddr << ", " << noffH.initData.size);
        executable->ReadAt(
		&(kernel->machine->mainMemory[noffH.initData.virtualAddr]),
			noffH.initData.size, noffH.initData.inFileAddr);
    #endif
    #ifdef VIRTMEM
    int startPage=divRoundDown(noffH.initData.virtualAddr,PageSize);
    int endPage=divRoundDown(noffH.initData.virtualAddr+noffH.initData.size-1,PageSize);
    for (int i=startPage;i<=endPage;++i) {
        this->pageInfo[i].status=(this->pageInfo[i].status!=vmpsInvalid)?vmpsMixed:vmpsData;
    }
    #endif
    }

#ifdef RDATA
    if (noffH.readonlyData.size > 0) {
        DEBUG(dbgAddr, "Initializing read only data segment.");
    #ifndef VIRTMEM
	DEBUG(dbgAddr, noffH.readonlyData.virtualAddr << ", " << noffH.readonlyData.size);
        executable->ReadAt(
		&(kernel->machine->mainMemory[noffH.readonlyData.virtualAddr]),
			noffH.readonlyData.size, noffH.readonlyData.inFileAddr);
    #endif
    #ifdef VIRTMEM
    int startPage=divRoundDown(noffH.readonlyData.virtualAddr,PageSize);
    int endPage=divRoundDown(noffH.readonlyData.virtualAddr+noffH.readonlyData.size-1,PageSize);
    for (int i=startPage;i<=endPage;++i) {
        this->pageInfo[i].status=(this->pageInfo[i].status!=vmpsInvalid)?vmpsMixed:vmpsRData;
    }
    #endif
    }
#endif

    #ifdef VIRTMEM
    if (noffH.uninitData.size > 0) {
        DEBUG(dbgAddr, "Initializing uninitialized data segment.");
    int startPage=divRoundDown(noffH.uninitData.virtualAddr,PageSize);
    int endPage=divRoundDown(noffH.uninitData.virtualAddr+noffH.uninitData.size-1,PageSize);
    for (int i=startPage;i<=endPage;++i) {
        this->pageInfo[i].status=(this->pageInfo[i].status!=vmpsInvalid)?vmpsMixed:vmpsDataUninit;
    }
    }
    DEBUG(dbgAddr, "Initializing stack segment.");
    for (int i=this->numPages-1;i>=0;--i) {
        if (this->pageInfo[i].status==vmpsInvalid) this->pageInfo[i].status=vmpsStack;
        else break;
    }
    #endif

    #ifndef VIRTMEM
    delete executable;			// close file
    #endif
    #ifdef VIRTMEM
    this->executable=executable;
    this->noffH=noffH;
    this->swapFileName=new char[256];//warning: buffer overflow may occur
    sprintf(swapFileName,"%s.swap",fileName);
    kernel->fileSystem->Create(swapFileName);
    this->swapArea=kernel->fileSystem->Open(swapFileName);
    this->DEBUGprint();
    #endif
    return TRUE;			// success
}

//----------------------------------------------------------------------
// AddrSpace::Execute
// 	Run a user program using the current thread
//
//      The program is assumed to have already been loaded into
//      the address space
//
//----------------------------------------------------------------------

void
AddrSpace::Execute()
{

    kernel->currentThread->space = this;

    this->InitRegisters();		// set the initial register values
    this->RestoreState();		// load page table register

    kernel->machine->Run();		// jump to the user progam

    ASSERTNOTREACHED();			// machine->Run never returns;
					// the address space exits
					// by doing the syscall "exit"
}


//----------------------------------------------------------------------
// AddrSpace::InitRegisters
// 	Set the initial values for the user-level register set.
//
// 	We write these directly into the "machine" registers, so
//	that we can immediately jump to user code.  Note that these
//	will be saved/restored into the currentThread->userRegisters
//	when this thread is context switched out.
//----------------------------------------------------------------------

void
AddrSpace::InitRegisters()
{
    Machine *machine = kernel->machine;
    int i;

    for (i = 0; i < NumTotalRegs; i++)
	machine->WriteRegister(i, 0);

    // Initial program counter -- must be location of "Start", which
    //  is assumed to be virtual address zero
    machine->WriteRegister(PCReg, 0);

    // Need to also tell MIPS where next instruction is, because
    // of branch delay possibility
    // Since instructions occupy four bytes each, the next instruction
    // after start will be at virtual address four.
    machine->WriteRegister(NextPCReg, 4);

   // Set the stack register to the end of the address space, where we
   // allocated the stack; but subtract off a bit, to make sure we don't
   // accidentally reference off the end!
    machine->WriteRegister(StackReg, numPages * PageSize - 16);
    DEBUG(dbgAddr, "Initializing stack pointer: " << numPages * PageSize - 16);
}

//----------------------------------------------------------------------
// AddrSpace::SaveState
// 	On a context switch, save any machine state, specific
//	to this address space, that needs saving.
//
//	For now, don't need to save anything!
//----------------------------------------------------------------------

void AddrSpace::SaveState()
{}

//----------------------------------------------------------------------
// AddrSpace::RestoreState
// 	On a context switch, restore the machine state so that
//	this address space can run.
//
//      For now, tell the machine where to find the page table.
//----------------------------------------------------------------------

void AddrSpace::RestoreState()
{
    kernel->machine->pageTable = pageTable;
    kernel->machine->pageTableSize = numPages;
}


//----------------------------------------------------------------------
// AddrSpace::Translate
//  Translate the virtual address in _vaddr_ to a physical address
//  and store the physical address in _paddr_.
//  The flag _isReadWrite_ is false (0) for read-only access; true (1)
//  for read-write access.
//  Return any exceptions caused by the address translation.
//----------------------------------------------------------------------
ExceptionType
AddrSpace::Translate(unsigned int vaddr, unsigned int *paddr, int isReadWrite)
{
    TranslationEntry *pte;
    int               pfn;
    unsigned int      vpn    = vaddr / PageSize;
    unsigned int      offset = vaddr % PageSize;

    if(vpn >= numPages) {
        return AddressErrorException;
    }

    pte = &pageTable[vpn];

    if(isReadWrite && pte->readOnly) {
        return ReadOnlyException;
    }

    pfn = pte->physicalPage;

    // if the pageFrame is too big, there is something really wrong!
    // An invalid translation was loaded into the page table or TLB.
    if (pfn >= NumPhysPages) {
        DEBUG(dbgAddr, "Illegal physical page " << pfn);
        return BusErrorException;
    }

    pte->use = TRUE;          // set the use, dirty bits

    if(isReadWrite)
        pte->dirty = TRUE;

    *paddr = pfn*PageSize + offset;

    ASSERT((*paddr < MemorySize));

    //cerr << " -- AddrSpace::Translate(): vaddr: " << vaddr <<
    //  ", paddr: " << *paddr << "\n";

    return NoException;
}


#ifdef VIRTMEM
VirtMemPageInfo::VirtMemPageInfo() {
    this->status=vmpsInvalid;
    this->swapAddr=-1;
}

VirtMemMRAllocator::VirtMemMRAllocator(TranslationEntry *pageTable) {
    this->pageTable=pageTable;
    this->physMemStatus=new TranslationEntry*[NumPhysPages];
}

int VirtMemMRAllocator::Allocate() {
    DEBUG(dbgAddr,"MRAllocator::Allocate");
    this->updatePhysMemStatus();
    //look for an empty page
    for (int i=last_position; i<NumPhysPages; ++i) {//start from last_position, do round-robin
        if (this->physMemStatus[i]==NULL) return last_position=i;
    }
    for (int i=0; i<last_position-1; ++i) {
        if (this->physMemStatus[i]==NULL) return last_position=i;
    }
    #ifdef VIRTMEM_SWAPTEST
    //in swap_test, M=1 is selected
    for (int i=last_position; i<NumPhysPages; ++i) {
        if (this->physMemStatus[i]->dirty) return last_position=i;
    }
    for (int i=0; i<last_position-1; ++i) {
        if (this->physMemStatus[i]->dirty) return last_position=i;
    }
    #endif
    //look for a page whose use=0 & dirty=0
    for (int i=last_position; i<NumPhysPages; ++i) {
        if (!this->physMemStatus[i]->use && !this->physMemStatus[i]->dirty) return last_position=i;
    }
    for (int i=0; i<last_position-1; ++i) {
        if (!this->physMemStatus[i]->use && !this->physMemStatus[i]->dirty) return last_position=i;
    }
    //look for a page whose use=1 & dirty=0
    for (int i=last_position; i<NumPhysPages; ++i) {
        if (this->physMemStatus[i]->use && !this->physMemStatus[i]->dirty) return last_position=i;
    }
    for (int i=0; i<last_position-1; ++i) {
        if (this->physMemStatus[i]->use && !this->physMemStatus[i]->dirty) return last_position=i;
    }
    //look for a page whose use=0 & dirty=1
    for (int i=last_position; i<NumPhysPages; ++i) {
        if (!this->physMemStatus[i]->use && this->physMemStatus[i]->dirty) return last_position=i;
    }
    for (int i=0; i<last_position-1; ++i) {
        if (!this->physMemStatus[i]->use && this->physMemStatus[i]->dirty) return last_position=i;
    }
    //look for a page whose use=1 & dirty=1
    for (int i=last_position; i<NumPhysPages; ++i) {
        if (this->physMemStatus[i]->use && this->physMemStatus[i]->dirty) return last_position=i;
    }
    for (int i=0; i<last_position-1; ++i) {
        if (this->physMemStatus[i]->use && this->physMemStatus[i]->dirty) return last_position=i;
    }
    ASSERTNOTREACHED();
}

void VirtMemMRAllocator::TimerCallback() {
    DEBUG(dbgAddr,"VirtMemMRAllocator::TimerCallback "<<timer_count);
    if (++timer_count < 5) return;
    timer_count=0;
    for (int i=0;i<NumVirtualPages;++i)
        this->pageTable->use=false;
}

void VirtMemMRAllocator::updatePhysMemStatus() {
    int i;
    for (i=0; i<NumPhysPages; ++i) this->physMemStatus[i]=NULL;
    for (i=0; i<NumVirtualPages; ++i) {
        if (this->pageTable[i].valid) {
            ASSERT(this->physMemStatus[this->pageTable[i].physicalPage]==NULL);
            this->physMemStatus[this->pageTable[i].physicalPage]=&(this->pageTable[i]);
        }
    }
}

void AddrSpace::DEBUGprint() {
    for (int i=0;i<NumVirtualPages;++i) {
        TranslationEntry* t=&(this->pageTable[i]);
        VirtMemPageInfo* p=&(this->pageInfo[i]);
        DEBUG(dbgAddr,"$ vp"<<i<<"=>"<<t->physicalPage<<", valid="<<t->valid<<", R="<<t->use<<", M="<<t->dirty<<", status="<<p->status<<", swap"<<p->swapAddr);
    }
}

void AddrSpace::TimerCallback() {
    VirtMemMRAllocator* mr=(VirtMemMRAllocator*)this->allocator;
    mr->TimerCallback();
}

void AddrSpace::SwapOut(unsigned int virtualPage) {
    this->DEBUGprint();
    DEBUG(dbgAddr,"SwapOut "<<virtualPage);
    ASSERT(this->pageTable[virtualPage].valid);
    bool dirty=this->pageTable[virtualPage].dirty;
    bool needsave=false;
    switch (this->pageInfo[virtualPage].status) {
        case vmpsCode:
        #ifdef RDATA
        case vmpsRData:
        #endif
            break;
        case vmpsData:
        case vmpsDataUninit:
        case vmpsStack:
        case vmpsMixed:
            needsave=dirty;
            break;
        case vmpsSwap:
            needsave=true;
            break;
        default:
            ASSERTNOTREACHED();
    }
    if (needsave) {
        this->pageInfo[virtualPage].status=vmpsSwap;
        this->updateSwapStatus();
        for (int i=0;i<NumSwapPages;++i) {//find a free swap page
            if (this->swapStatus[i]==NULL) {
                this->pageInfo[virtualPage].swapAddr=i;
                break;
            }
        }
        ASSERT(this->pageInfo[virtualPage].swapAddr>=0);
        DEBUG(dbgAddr,"        "<<virtualPage<<" saved to swapPage"<<this->pageInfo[virtualPage].swapAddr);
        this->swapArea->WriteAt(VirtMemPhysStart(this,virtualPage), PageSize, this->pageInfo[virtualPage].swapAddr * PageSize);
    }
    this->pageTable[virtualPage].valid=FALSE;
}

void AddrSpace::SwapIn(unsigned int virtualPage, unsigned int physicalPage) {
    VirtMemPageInfo* p=&(this->pageInfo[virtualPage]);
    TranslationEntry* t=&(this->pageTable[virtualPage]);
    ASSERT(!t->valid);
    t->valid=true;
    t->physicalPage=physicalPage;
    switch (p->status) {
        case vmpsCode:
            DEBUG(dbgAddr,"SwapIn "<<virtualPage<<","<<physicalPage<<",vmpsCode");
            this->SwapIn_noff(&(this->noffH.code),virtualPage,physicalPage);
            break;
        case vmpsData:
            DEBUG(dbgAddr,"SwapIn "<<virtualPage<<","<<physicalPage<<",vmpsData");
            this->SwapIn_noff(&(this->noffH.initData),virtualPage,physicalPage);
            break;
        #ifdef RDATA
        case vmpsRData:
            DEBUG(dbgAddr,"SwapIn "<<virtualPage<<","<<physicalPage<<",vmpsRData");
            this->SwapIn_noff(&(this->noffH.readonlyData),virtualPage,physicalPage);
            break;
        #endif
        case vmpsDataUninit:
            DEBUG(dbgAddr,"SwapIn "<<virtualPage<<","<<physicalPage<<",vmpsDataUninit");
            bzero(VirtMemPhysStart(this,virtualPage),PageSize);
            break;
        case vmpsStack:
            DEBUG(dbgAddr,"SwapIn "<<virtualPage<<","<<physicalPage<<",vmpsStack");
            break;
        case vmpsMixed:
            DEBUG(dbgAddr,"SwapIn "<<virtualPage<<","<<physicalPage<<",vmpsMixed");
            this->SwapIn_mixed(virtualPage,physicalPage);
            break;
        case vmpsSwap:
            DEBUG(dbgAddr,"SwapIn "<<virtualPage<<","<<physicalPage<<",vmpsSwap");
            ASSERT(p->swapAddr>=0);
            this->swapArea->ReadAt(VirtMemPhysStart(this,virtualPage), PageSize, this->pageInfo[virtualPage].swapAddr * PageSize);
            break;
        default:
            DEBUG(dbgAddr,"SwapIn "<<virtualPage<<","<<physicalPage<<",vmpsInvalid");
            ASSERTNOTREACHED();
    }
    p->swapAddr=-1;//free the swap page
    t->readOnly=(p->status == vmpsCode || p->status == vmpsRData);
    t->use=false;
    t->dirty=false;
}

void AddrSpace::SwapIn_noff(Segment* segment, unsigned int virtualPage, unsigned int physicalPage) {
    //determine whether segment overlaps this page, if so then load its contents
    if (segment->size<=0) return;
    int startPage=divRoundDown(segment->virtualAddr,PageSize);
    int endPage=divRoundDown(segment->virtualAddr+segment->size-1,PageSize);
    if (startPage>virtualPage || endPage<virtualPage) return;//no overlap
    bool isStart=virtualPage==startPage;
    bool isEnd=virtualPage==endPage;
    int offsetStart=isStart?(segment->virtualAddr % PageSize):0;
    int offsetEnd=isEnd?((segment->virtualAddr+segment->size-1) % PageSize):PageSize-1;
    int size=offsetEnd-offsetStart+1;
    ASSERT(size>0);
    int position=segment->inFileAddr+(virtualPage-startPage)*PageSize+offsetStart;
    this->executable->ReadAt(VirtMemPhysStart(this,virtualPage),size,position);
}

void AddrSpace::SwapIn_mixed(unsigned int virtualPage, unsigned int physicalPage) {
    //zero out the page in case there is uninitData
    bzero(VirtMemPhysStart(this,physicalPage),PageSize);
    //try load from each segment
    this->SwapIn_noff(&(this->noffH.code),virtualPage,physicalPage);
    this->SwapIn_noff(&(this->noffH.initData),virtualPage,physicalPage);
    #ifdef RDATA
    this->SwapIn_noff(&(this->noffH.readonlyData),virtualPage,physicalPage);
    #endif
}


void AddrSpace::updateSwapStatus() {
    int i;
    for (i=0; i<NumSwapPages; ++i) this->swapStatus[i]=NULL;
    for (i=0; i<NumVirtualPages; ++i) {
        int p=this->pageInfo[i].swapAddr;
        if (p>=0) {
            ASSERT(this->swapStatus[p]==NULL);
            this->swapStatus[p]=&(this->pageInfo[i]);
        }
    }
}

void AddrSpace::EnsureIn(unsigned int virtualPage) {
    DEBUG(dbgAddr,"EnsureIn "<<virtualPage);
    if (this->pageTable[virtualPage].valid) return;
    int physicalPage=this->allocator->Allocate();
    for (int i=0;i<NumVirtualPages;++i)
        if (this->pageTable[i].valid && this->pageTable[i].physicalPage==physicalPage)
            this->SwapOut(i);
    this->SwapIn(virtualPage, physicalPage);
    this->DEBUGprint();
}

#endif

