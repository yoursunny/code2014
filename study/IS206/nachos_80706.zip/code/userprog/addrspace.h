// addrspace.h
//	Data structures to keep track of executing user programs
//	(address spaces).
//
//	For now, we don't keep any information about address spaces.
//	The user level CPU state is saved and restored in the thread
//	executing the user program (see thread.h).
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation
// of liability and disclaimer of warranty provisions.

#ifndef ADDRSPACE_H
#define ADDRSPACE_H

#include "copyright.h"
#include "filesys.h"

#ifdef VIRTMEM
#include "noff.h"
enum VirtMemPageStatus {//represent the type and status of a virtual page
  vmpsInvalid,//invalid, shouldn't be accessed
  vmpsCode,//code page, read from noff binary
  vmpsData,//data page, never modified, read from noff binary
  #ifdef RDATA
  vmpsRData,//readonly-data page, read from noff binary
  #endif
  vmpsDataUninit,//uninitialized data page, never modified, allocate and zero out
  vmpsStack,//stack page, never modified, allocate only
  vmpsMixed,//mixed page, never modified, read from noff binary
  vmpsSwap//data/rdata/mixed page, modified, read from swap area
};

class VirtMemPageInfo {//holds information about one page
  public:
    VirtMemPageInfo();
    int virtualPage;//virtual page #
    VirtMemPageStatus status;//type & status of this page
    int swapAddr;//offset in swap area of DataSwap pages, -1=invalid
};

class VirtMemAllocator {//abstract memory allocator
  public:
    virtual int Allocate() = 0;//allocate one sector, returns virtualPage#
};

class VirtMemMRAllocator : public VirtMemAllocator {//allocator according to Modified,Reference bits
  public:
    VirtMemMRAllocator(TranslationEntry *pageTable);
    int Allocate();
    void TimerCallback();//timer callback, resets all Reference bits
  private:
    TranslationEntry *pageTable;
    int last_position;
    int timer_count;
    TranslationEntry **physMemStatus;//valid Translation entry sorted by physicalPage
    void updatePhysMemStatus();
};

#ifndef VIRTMEM_TEST
const int NumVirtualPages=256;
const int NumSwapPages=64;
#endif
#ifdef VIRTMEM_TEST
const int NumVirtualPages=24;
const int NumSwapPages=12;
#endif

#define VirtMemPhysStart(space,virtualPage) (kernel->machine->mainMemory+(space->pageTable[virtualPage].physicalPage)*PageSize)

#endif

#define UserStackSize		1024 	// increase this as necessary!

class AddrSpace {
  public:
    AddrSpace();			// Create an address space.
    ~AddrSpace();			// De-allocate an address space

    bool Load(char *fileName);		// Load a program into addr space from
                                        // a file
					// return false if not found

    void Execute();             	// Run a program
					// assumes the program has already
                                        // been loaded

    void SaveState();			// Save/restore address space-specific
    void RestoreState();		// info on a context switch

    // Translate virtual address _vaddr_
    // to physical address _paddr_. _mode_
    // is 0 for Read, 1 for Write.
    ExceptionType Translate(unsigned int vaddr, unsigned int *paddr, int mode);
    #ifdef VIRTMEM
    //make sure virtualPage is in mainMemory, set its TranslationEntry and load its data
    void EnsureIn(unsigned int virtualPage);
    void DEBUGprint();
    void TimerCallback();
    #endif

  private:
    TranslationEntry *pageTable;	// Assume linear page table translation
					// for now!
    unsigned int numPages;		// Number of pages in the virtual
					// address space

    void InitRegisters();		// Initialize user-level CPU registers,
					// before jumping to user code
    #ifdef VIRTMEM
    VirtMemPageInfo *pageInfo;
    VirtMemAllocator *allocator;
    OpenFile *executable;
    NoffHeader noffH;
    //take virtualPage out of mainMemory
    void SwapOut(unsigned int virtualPage);
    //put virtualPage on physicalPage and load its contents, assume physicalPage is unused
    void SwapIn(unsigned int virtualPage, unsigned int physicalPage);
    //load contents from a noff segment
    void SwapIn_noff(Segment* segment, unsigned int virtualPage, unsigned int physicalPage);
    //load contents from noff segments for a vmpsMixed page
    void SwapIn_mixed(unsigned int virtualPage, unsigned int physicalPage);
    char* swapFileName;
    OpenFile* swapArea;
    VirtMemPageInfo **swapStatus;//PageInfo entry sorted by swapAddr
    void updateSwapStatus();
    #endif

};

#endif // ADDRSPACE_H
