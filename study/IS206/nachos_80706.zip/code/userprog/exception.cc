// exception.cc
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation
// of liability and disclaimer of warranty provisions.

#ifdef PATCH_SYSCALL1
#include <stdio>
#endif

#include "copyright.h"
#include "main.h"
#include "syscall.h"
#include "ksyscall.h"
//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2.
//
// If you are handling a system call, don't forget to increment the pc
// before returning. (Or else you'll loop making the same system call forever!)
//
//	"which" is the kind of exception.  The list of possible exceptions
//	is in machine.h.
//----------------------------------------------------------------------

void
ExceptionHandler(ExceptionType which)
{
    int type = kernel->machine->ReadRegister(2);

    DEBUG(dbgSys, "Received Exception " << which << " type: " << type << "\n");

    switch (which) {
    case SyscallException:
      switch(type) {
      case SC_Halt:
	DEBUG(dbgSys, "Shutdown, initiated by user program.\n");

	SysHalt();

	ASSERTNOTREACHED();
	break;

      case SC_Add:
	DEBUG(dbgSys, "Add " << kernel->machine->ReadRegister(4) << " + " << kernel->machine->ReadRegister(5) << "\n");

	/* Process SysAdd Systemcall*/
	int result;
	result = SysAdd(/* int op1 */(int)kernel->machine->ReadRegister(4),
			/* int op2 */(int)kernel->machine->ReadRegister(5));

	DEBUG(dbgSys, "Add returning with " << result << "\n");
	/* Prepare Result */
	kernel->machine->WriteRegister(2, (int)result);

	/* Modify return point */
	{
	  /* set previous programm counter (debugging only)*/
	  kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));

	  /* set programm counter to next instruction (all Instructions are 4 byte wide)*/
	  kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);

	  /* set next programm counter for brach execution */
	  kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
	}

	return;

	ASSERTNOTREACHED();

	break;

    #ifdef PATCH_SYSCALLS1
    case SC_Exit:
        {
            int SC_Exit_status=(int)kernel->machine->ReadRegister(4);
            DEBUG(dbgSys, "Thread "<<kernel->currentThread->getName()<<" call Exit with code "<<SC_Exit_status);
            SysHalt();
            ASSERTNOTREACHED();
        }
        break;
    case SC_Exec:
        {
            int SC_Exec_name_addr=(int)kernel->machine->ReadRegister(4);//exec_name
            //note: exec_name is stored in MIPS mem, not host mem, must copy from MIPS to host
            char* SC_Exec_name=new char[256];
            int SC_Exec_ch=-1;
            int SC_Exec_name_i;
            for (SC_Exec_name_i=0;SC_Exec_ch!=0&&SC_Exec_name_i<256;++SC_Exec_name_i) {
                kernel->machine->ReadMem(SC_Exec_name_addr+SC_Exec_name_i,1,&SC_Exec_ch);
                SC_Exec_name[SC_Exec_name_i]=(char)SC_Exec_ch;
            }
            ASSERT(SC_Exec_name_i<256);//exec_name should be less than 256 chars
            DEBUG(dbgSys,"Thread "<<kernel->currentThread->getName()<<" exec "<<SC_Exec_name);
            Thread* SC_Exec_thread=new Thread(SC_Exec_name);//warning: SC_Exec_name cause memory leak!!
            SC_Exec_thread->Fork((VoidFunctionPtr)NoffProcess,SC_Exec_name);
            kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
            kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
            kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
            return;
        }
        break;
    case SC_ThreadFork:
        {
            int SC_ThreadFork_func=(int)kernel->machine->ReadRegister(4);
            char* SC_ThreadFork_name=new char[64];//warning: buffer overflow may occur
            sprintf(SC_ThreadFork_name,"%s%d",kernel->currentThread->getName(),SC_ThreadFork_func);
            DEBUG(dbgSys,"Thread "<<kernel->currentThread->getName()<<" fork "<<SC_ThreadFork_func);
            Thread* SC_ThreadFork_thread=new Thread(SC_ThreadFork_name);//warning: SC_ThreadFork_name cause memory leak!!
            SC_ThreadFork_thread->Fork((VoidFunctionPtr)NoffThread,(void *)SC_ThreadFork_func);
            kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
            kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
            kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
            return;
        }
        break;
    case SC_ThreadYield:
        {
            DEBUG(dbgSys,"Thread "<<kernel->currentThread->getName()<<" yield");
            kernel->currentThread->Yield();
            kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
            kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
            kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
            return;
        }
        break;
    case SC_ThreadExit:
        {
            int SC_ThreadExit_status=(int)kernel->machine->ReadRegister(4);
            DEBUG(dbgSys,"Thread "<<kernel->currentThread->getName()<<" exit with code "<<SC_ThreadExit_status);
            //status return is not supported
            kernel->currentThread->Finish();
            kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
            kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
            kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
            return;
        }
        break;
    case SC_Clock:
        {
            int SC_Clock_tick=kernel->stats->totalTicks;
            DEBUG(dbgSys,kernel->currentThread->getName()<<" asks current clock "<<SC_Clock_tick);
            kernel->machine->WriteRegister(2,SC_Clock_tick);
            kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
            kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
            kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
            return;
        }
        break;
    #ifdef PRIORITY_SCHED
    case SC_SetPriority:
        {
            int SC_SetPriority_newV=(int)kernel->machine->ReadRegister(4);
            int SC_SetPriority_oldV=kernel->currentThread->priority;
            DEBUG(dbgSys,kernel->currentThread->getName()<<" sets its priority from "<<SC_SetPriority_oldV<<" to "<<SC_SetPriority_newV<<", takes effect on next scheduler operation");
            kernel->machine->WriteRegister(2,SC_SetPriority_oldV);
            kernel->currentThread->priority=SC_SetPriority_newV;
            kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
            kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
            kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
            return;
        }
        break;
    #endif
    #endif

      default:
	cerr << "Unexpected system call " << type << "\n";
	break;
      }
      break;
    #ifdef VIRTMEM
    case PageFaultException:
      {
        ++kernel->stats->numPageFaults;
        int badVAddr=(int)kernel->machine->ReadRegister(BadVAddrReg);
        int virtualPage=divRoundDown(badVAddr,PageSize);
        kernel->currentThread->space->EnsureIn(virtualPage);
        return;
      }
      break;
    #endif
    default:
      cerr << "Unexpected user mode exception" << (int)which << "\n";
      break;
    }
    ASSERTNOTREACHED();
}
