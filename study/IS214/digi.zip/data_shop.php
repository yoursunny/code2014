<?php
require_once 'common.php';
query_json('SELECT * FROM shop',array());

?>