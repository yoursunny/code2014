var libbase='lib/';

//JS基础类库Prototype 1.5.1.1来自http://prototypejs.org
document.write('<script type="text/javascript" src="'+libbase+'prototype.js"></script>');

//显示效果库script.aculo.us v1.7.1_beta3来自http://script.aculo.us
document.write('<script type="text/javascript" src="'+libbase+'scriptaculous.js?load=builder,effects,controls,slider"></script>');

//自定义库，包含：cookie，XSLT
document.write('<script type="text/javascript" src="'+libbase+'lib1.js"></script>');
