#include "stdio.h"
#include "string.h"
#include "math.h"

void IsBuKeYue(int Fx[]);
void GetFx(int Fx[]);
void PrintFx(const int Fx[]);
void Mul(int xiangchacishu, int Gx[], int result[]);
void Add(int Fx[], int Gx[]);
int GetTimes(int Fx[]);


void Getgx(int Fx[]);
void MulOneTime(int out[], int in[], const int gx[]);
void ModOneTime(int out[], int in[], int fx[]);
void Add2(int Fx[], int Gx[]);
int GetTimes2(int Fx[]);
void PrintFx2(const int Fx[]);
bool EqualOne(const int fx[]);

void GetE(int Fx[], const int Gx[]);
void GetB(int Fx[]);


const int Gx[7][9] = { {0,1,0,0,0,0,0,0,0}, {1,1,0,0,0,0,0,0,0}, {1,1,1,0,0,0,0,0}, {1,0,1,1,0,0,0,0,0}, {1,1,0,1,0,0,0,0,0}, {1,0,0,1,1,0,0,0,0}, {1,1,0,0,1,0,0,0,0}};

const int gx[4][13] = { {0,1,0,0,0,0,0,0,0,0,0,0,0}, {1,1,0,0,0,0,0,0,0,0,0,0,0}, {0,0,0,1,0,0,0,0,0,0,0,0,0}, {0,0,0,0,0,1,0,0,0,0,0,0,0}};

int gxnum=4;

int main(void)
{
printf("����������ˮ˼ԴBBSվ����connnent�ṩ\n�������ѧϰƵ�� http://study.yoursunny.com ��gcc��������windows�汾\n���Գ������ȷ�������κε�������ο�ʹ��\n\n");
	int Fx[9];
	printf("ֻ֧��8������ż���ݶ���ʽ\n");
	printf("����ʱ������8-0����ϵ������x^6+1������0 0 1 0 0 0 0 0 1\n");
	GetFx(Fx);

	int choose;

	while(1)
	{		
		printf("\n����1��1������2��2������3��3������4�������������0�˳�\n\n");

		scanf("%d", &choose);
		//printf("%d",gxnum);
		
		switch(choose)
		{
		case 1: IsBuKeYue(Fx); break;
		case 2: 
			{
				int temp[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
				memcpy(temp, Fx, 36);
				Getgx(temp); break;
			}		
		case 3:
			{
				if(gxnum != 4)
				{
					int temp[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
					memcpy(temp, Fx, 36);
					GetE(temp, gx[gxnum]);
				}
				else
				{
					printf("������ɵ�2��");
				}
				break;
			}
		case 4:
			{
				int temp[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
				memcpy(temp, Fx, 36);
				GetB(temp);break;
			}
case 0: return 0;
		}
	}
	printf("֮�������������\n\n");
	
	return 0;		
}

void GetB(int Fx[])
{
	int times;
	int temp1[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0}, temp2[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0}, per[13];

	times = GetTimes2(Fx);

	for(int i=0; i<4; i++)
	{
		memcpy(per, gx[i], 52);
		memcpy(temp2, gx[i], 52);
		memcpy(temp1, gx[i], 52);

		printf("����B=");
		PrintFx2(per);
		printf("\b\b\b��������\n");
		for(int j = 1; j<=times; j++)
		{	
			//printf("%d\\\\\\\\\n",j);
			printf("B^%d = ",(int)pow(2.0,j-1) );
			for(int k = 0; k < (int)pow(2.0,j-1)/2; k++)
			{
				for(int l=0; l<13; l++) temp2[l] = 0;
				MulOneTime(temp2, temp1, per);
				ModOneTime(temp1, temp2, Fx);				
			}

			PrintFx2(temp1);
			printf("\b\b\b   \n");
		}
		printf("\n");


	}
}

void GetE(int Fx[], const int Gx[])
{
	int num,time, times, total, FxTime;
	int temp1[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0}, temp2[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0}, per[13];


	printf("\n��Ԫ����\n");
	scanf("%d", &num);
	switch(num)
	{
	case 4:time = 2;break;
	case 8:time = 3;break;
	case 16:time = 4;break;
	}
	
	FxTime=GetTimes2(Fx);
	//printf("FxTime = %d",FxTime);
	times = (pow(2.0,FxTime) - 1)/(pow(2.0,time)-1);
	

	printf("f(x)������ԪΪ");
	PrintFx2(Gx);
	printf("\b\b\b��\n����%dԪ����E������ԪΪ\ng%d=g%d=",num,time,times);
	memcpy(temp1, Gx, 52);
	memcpy(per,Gx, 52);
	for(int i = 0; i<times -1 ; i++)
	{
		MulOneTime(temp2, temp1, per);
		ModOneTime(temp1, temp2, Fx);
		for(int k=0; k<13; k++) temp2[k] = 0;
	}
	PrintFx2(temp1);
	printf("\b\b\b\nE={0");
	
	printf(", g%d^%d = ",time,1);
	PrintFx2(temp1);

	memcpy(per, temp1,52);
	for(int i = 2; i<num; i++)
	{
		MulOneTime(temp2, temp1, per);
		ModOneTime(temp1, temp2, Fx);
		for(int k=0; k<13; k++) temp2[k] = 0;
		printf("\b\b\b, g%d^%d = ",time,i);
		PrintFx2(temp1);	
	}
	printf("\b\b\b.}\n");
	printf("֮�����������\n");

}


void Getgx(int Fx[])
{
	int times = 0;
	int sum = 0, count = 0 , a[3];
	int i, j;
	int temp1[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0}, temp2[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
	int flag =0;
	
	times = GetTimes2(Fx);

	switch(times)
	{
	case 8: sum = 255; count = 3; a[0] = 15; a[1] = 51; a[2] = 85; break;
	case 6: sum = 63; count = 2; a[0] = 9; a[1] = 21; a[2] = 0;break;
	case 4: sum = 15; count = 2; a[0] = 3; a[1] = 5;a[2] = 0;break;
	}

	printf("��Ϊ|F*2^%d| = 2^%d - 1 = %d����������\n", times, times, sum);
	for(i = 0; i<count; i++)
	{
		printf("g(x)^%d��1(mod(f(x))�� ", a[i]);
	}
	printf("\n��Ԫ��g(x)��������Ԫ");

	for(i = 0; i < 4; i++)
	{
		flag = 0;
		printf("\n\n����g(x)=");
		PrintFx2(gx[i]);
		printf("\b\b\b����\n");

		memcpy(temp1, gx[i], 52);

		for(j = 0; j < a[0] - 1; j++)
		{
			MulOneTime(temp2, temp1, gx[i]);
			ModOneTime(temp1, temp2, Fx);
			
			for(int k=0; k<13; k++) temp2[k] = 0;
		}
		if(EqualOne(temp1)) 
		{
			flag = 1;
			printf("x^%d��",a[0]);
			PrintFx2(temp1);
			printf("\b\b\b��1�� ");

		}
		else
		{

			printf("x^%d��",a[0]);
			PrintFx2(temp1);
			printf("\b\b\b��1�� ");
		}

		for(j = 0; j < a[1] - a[0]; j++)
		{
			MulOneTime(temp2, temp1, gx[i]);
			ModOneTime(temp1, temp2, Fx);
			for(int k=0; k<13; k++) temp2[k] = 0;

		}
		if(EqualOne(temp1)) 
		{
			flag = 1;
			printf("x^%d��",a[1]);
			PrintFx2(temp1);
			printf("\b\b\b��1�� ");

		}
		else
		{
			printf("x^%d��",a[1]);
			PrintFx2(temp1);
			printf("\b\b\b��1�� ");
		}

		if(a[2] != 0)
		{
			for(j = 0; j < a[2] - a[1]; j++)
			{
				MulOneTime(temp2, temp1, gx[i]);
				ModOneTime(temp1, temp2, Fx);
				for(int k=0; k<13; k++) temp2[k] = 0;

			}
			if(EqualOne(temp1)) 
			{
				flag = 1;
				printf("x^%d��",a[2]);
				PrintFx2(temp1);
				printf("\b\b\b��1�� ");

			}
			else
			{
				printf("x^%d��",a[2]);
				PrintFx2(temp1);
				printf("\b\b\b��1�� ");
			}	
		}

		if(flag == 0)
		{
			printf("\n����F2[x]/(f(x))������Ԫ��g(x)=");
			PrintFx2(gx[i]);
			printf("\n");
			gxnum = i;
			return;
		}
	}
	
	printf("û�ҵ�����\n");
}

void MulOneTime(int out[], int in[], const int gx[])
{
	int i, j;
	int temp[13] = {0,0,0,0,0,0,0,0,0,0,0,0,0};

	for(i = 12; i>=0; i--)
	{
		if(gx[i]!=0)
		{
			for(j = GetTimes2(in); j >=0; j--)
			{
				temp[j + i] = in[j];
			}
			Add2(out, temp);
		}
		for(int k= 0; k<13; k++) temp[k] =0;
	}
	/*printf("!!!!");
	PrintFx2(out);
	printf("\b\b\b!!!!\n");*/

}
void ModOneTime(int out[], int in[], int fx[])
{
	int xiangchacishu;
	int tempyu[13],tempchushu[13],  tempshang[13]={0,0,0,0,0,0,0,0,0,0,0,0,0}; 

	memcpy(tempyu, in, 52);
	memcpy(tempchushu, fx, 52);

	while(1)
	{
		int tempres[13]={0,0,0,0,0,0,0,0,0,0,0,0,0};

		xiangchacishu = GetTimes2(tempyu) - GetTimes2(tempchushu);
		if( xiangchacishu < 0 )
		{
			memcpy(out, tempyu, 52);
			break;
		}

		tempshang[xiangchacishu] = 1;
		Mul(xiangchacishu, tempchushu, tempres);
		Add2(tempyu, tempres);
	};


}

void Add2(int Fx[], int Gx[])
{	
	int temp[13];

	for(int i=0; i<13; i++)
	{
		temp[i] = (Fx[i] + Gx[i])%2;
	}
	memcpy(Fx, temp, 52);
}

int GetTimes2(int Fx[])
{
	for(int i=12; i>0; i--)
	{
		if(Fx[i]==1)
		{
			return i;
		}
	}

	return 0;
}

void PrintFx2(const int Fx[])
{
	int i;
	
	for(i=12; i>0; i--)
	{
		if(Fx[i]!=0)
		{
			printf("X^%d + ",i);
		}
	}
	if(Fx[0]!=0)
	{
		printf("1 + ");
	}
	printf("\b\b\b   ");
}


bool EqualOne(const int fx[])
{
	return (fx[0]==1)&&(fx[1]==0)&&(fx[2]==0)&&(fx[3]==0)&&(fx[4]==0)&&(fx[5]==0)&&(fx[6]==0)&&(fx[7]==0)&&(fx[8]==0)&&(fx[9]==0)&&(fx[10]==0)&&(fx[11]==0)&&(fx[12]==0);
}


void IsBuKeYue(int Fx[])
{
	int times, half, trytime;
	int tempshang[9], tempyu[9], tempchushu[9], tempres[9];
	int i = 0;
	int xiangchacishu;

	times = GetTimes(Fx);
	half = times/2;

	switch(half)
	{
	case 4: trytime = 7;break;
	case 3: trytime = 5;break;
	case 2: trytime = 3;break;
	case 1: trytime = 2;break;
	};

	for(i = 0; i < 9; i++)
	{
		tempshang[i]=0;
		tempyu[i]=Fx[i];
		tempres[i]=0;
	}

	printf("��ΪF2[x]�е����д���<=%d/2�Ĳ���Լ����ʽΪ��\n",times);
	for(i = 0; i < trytime; i++)
	{
		memcpy(tempchushu, Gx[i], 36);
		PrintFx(tempchushu);
		printf("\n");
	}
	printf("\n");

	for(i = 0; i < trytime; i++)
	{
		printf("f(x) = ");
		memcpy(tempchushu, Gx[i], 36);
		for(int j = 0; j < 9; j++)
		{
			tempshang[j]=0;
			tempyu[j]=Fx[j];
			tempres[j]=0;
		}

		while(1)
		{
			for(int j = 0; j < 9; j++)
			{
				tempres[j]=0;
			}

			xiangchacishu = GetTimes(tempyu) - GetTimes(tempchushu);
			if( xiangchacishu < 0 )
			{
				printf("(");
				PrintFx(tempshang);
				printf("\b\b\b) * (");
				PrintFx(tempchushu);
				printf("\b\b\b) + ");
				PrintFx(tempyu);
				printf("\n");
				break;
			}

			tempshang[xiangchacishu] = 1;
			Mul(xiangchacishu, tempchushu, tempres);
			Add(tempyu, tempres);
		};
	}

	printf("֮�������������\n");
	return;
}

void Mul(int xiangchacishu, int Gx[], int result[])
{
	for(int i=GetTimes(Gx); i>=0; i--)
	{
		result[i + xiangchacishu] = Gx[i];
	}
}


void Add(int Fx[], int Gx[])
{	
	int temp[9];

	for(int i=0; i<9; i++)
	{
		temp[i] = (Fx[i] + Gx[i])%2;
	}
	memcpy(Fx, temp, 36);
}

int GetTimes(int Fx[])
{
	for(int i=8; i>0; i--)
	{
		if(Fx[i]!=0)
		{
			return i;
		}
	}

	return 0;
}



void GetFx(int Fx[])
{
	printf("����f(x)\n");
for (int i=8;i>=0;--i) {
printf("x^%d��ϵ����(1��0)��",i);
scanf("%d",&Fx[i]);
}
	printf("�����f(x)Ϊ\n");
	PrintFx(Fx);
	printf("\n");
}


void PrintFx(const int Fx[])
{
	int i;
	
	for(i=8; i>0; i--)
	{
		if(Fx[i]!=0)
		{
			printf("X^%d + ",i);
		}
	}
	if(Fx[0]!=0)
	{
		printf("1 + ");
	}
	printf("\b\b\b   ");
}

