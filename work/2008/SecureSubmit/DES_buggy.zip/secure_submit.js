//DH密钥协商 + DES加密，安全提交类
var SecureSubmit=Class.create({
	//初始化，指定服务端调用地址
	// POST a=genkey,g,n,X，返回Y
	// POST a=save,v=加密后的密码
	initialize:function(server) {
		this.server=server;
	},
	HEXdigits:['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'],
	rand:function() {
		//产生64-bit随机数
		var h='';
		for (var i=0;i<16;++i) {
			h+=this.HEXdigits[Math.floor(Math.random()*16)];
		}
		return biFromHex(h);
	},
	HEX_toString:function(h) {
		while (h.length<16) h='0'+h;
		var b='';
		for (var i=0;i<16;i+=2) {
			b+=String.fromCharCode(parseInt(h.substr(i,2),16));
		}
		return b;
	},
	prepare:function() {
		//64-bit key
		setMaxDigits(8);
		var compare_result;
		//随机产生1<g<n，不保密
		do {
			do {//g>1
				this.g=this.rand();
			} while (biCompare(this.g,bigOne)<=0);
			do {//n>1
				this.n=this.rand();
			} while (biCompare(this.n,bigOne)<=0);
			compare_result=biCompare(this.g,this.n);
		} while (compare_result==0);//直到g!=n
		if (compare_result > 0)//若g>n，交换
			{ var tmp=this.n; this.n=this.g; this.g=tmp; }
		this.x=this.rand();//随机产生x，保密
		this.X=biPowMod(this.g,this.x,this.n);//X=g^x mod n
		new Ajax.Request(this.server,{parameters:{a:'genkey',g:biToHex(this.g),n:biToHex(this.n),X:biToHex(this.X)},onComplete:this.prepare1.bind(this)});
	},
	prepare1:function(resp) {
		var o=resp.responseJSON;
		m=resp;
		//服务端随机产生y，保密；Y=g^y mod n
		this.Y=biFromHex(o.Y);
		this.K=biPowMod(this.Y,this.x,this.n);//K=Y^x mod n=X^y mod n
		this.key=this.HEX_toString(biToHex(this.K));
		this.key='11111111';
	},
	save:function(value) {
		var v=DES.encrypt(this.key,value);
		new Ajax.Request(this.server,{parameters:{a:'save',v:v}});
	}
});