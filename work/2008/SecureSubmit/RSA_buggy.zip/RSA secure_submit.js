var SecureSubmit=Class.create({
	initialize:function(server) {
		this.server=server;
	},
	prepare:function() {
		//new Ajax.Request(this.server,{method:'get',parameters:{a:'genkey'},onComplete:this.prepare1.bind(this)});
		this.key = new RSAKeyPair(
 "bb9",
 "721",
 "cd7"
);
	},
	prepare1:function(resp) {
		var o=resp.responseJSON;
		setMaxDigits(6);
		//this.key=new RSAKeyPair(o.e.toString(16),'0',o.m.toString(16));
	},
	save:function(value) {
		var v=encryptedString(this.key,value);
		new Ajax.Request(this.server,{method:'get',parameters:{a:'save',v:v}});
	}
});