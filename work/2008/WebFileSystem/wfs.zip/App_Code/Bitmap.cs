﻿using System;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 位图结构，类似于BitArray
    /// </summary>
    public struct Bitmap
    {
        public byte[] bytes;
        public bool this[int i]
        {
            get
            {
                byte mask = (byte)(0x01 << (i % 8));
                return (bytes[i / 8] & mask) != 0;
            }
            set
            {
                byte mask = (byte)(0x01 << (i % 8));
                if (value) bytes[i / 8] |= mask;
                else bytes[i / 8] &= (byte)(~mask);
            }
        }
        /// <summary>
        /// 一次设置连续的多个值
        /// </summary>
        public void SetRange(int start, int end, bool value)
        {
            byte v = value ? (byte)0xFF : (byte)0x00;
            int start_byte = start / 8 + (start % 8 == 0 ? 0 : 1);
            int end_byte = end / 8;
            for (int i = start; i < start_byte * 8; ++i) this[i] = value;
            for (int i = start_byte; i < end_byte; ++i) bytes[i] = v;
            for (int i = end_byte * 8; i < end; ++i) this[i] = value;
        }
    }
}