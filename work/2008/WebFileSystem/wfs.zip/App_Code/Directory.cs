﻿using System;
using System.IO;
using System.Collections.Generic;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 目录
    /// </summary>
    public class Directory : FileInfo, IEnumerable<FileInfo>
    {
        private inode inode_;
        public inode inode { get { return inode_; } }
        private string path;
        public Directory(inode inode, string path)
            : base(inode.fs, inode.id, path)
        {
            if (!inode.directory) throw new ArgumentException();
            inode_ = inode;
            this.path = path;
        }
        public static Directory Open(FileSystem fs, string path)
        {
            return new Directory(inode.Find(fs, path), path);
        }
        public IEnumerator<FileInfo> GetEnumerator()
        {
            return new DirectoryEnumberator(this);
        }
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        /// <summary>
        /// 在目录中增加文件或子目录
        /// </summary>
        public void AddChild(int inode, string filename)
        {
            byte[] fname = new System.Text.ASCIIEncoding().GetBytes(filename);
            int req_len = 8 + fname.Length + 1;//需要分配的目录项大小
            short rec_len = (short)req_len;
            DirectoryEnumberator en = (DirectoryEnumberator)GetEnumerator();
            while (en.next < req_len)//寻找可用的目录项位置
            {
                if (!en.MoveNext()) break;
            }
            if (en.next >= req_len)//找到了空隙
            {
                if (en.file.Position == 0)//在开头创建目录项
                {
                    rec_len = (short)en.next;
                }
                else//在中间创建目录项
                {
                    int old_name_len = en.current_filename.Length;
                    en.file.Position = en.entry_pos;//指向上一目录项开头
                    byte[] buffer1 = new byte[8];
                    en.file.Read(buffer1, 0, 8);
                    short old_rec_len = Util.get_uint16(buffer1, 4);
                    rec_len = (short)(old_rec_len - req_len - 1);
                    old_rec_len = (short)(8 + old_name_len + 1);//修改上一目录项rec_len字段
                    Util.put_uint16(buffer1, 4, old_rec_len);
                    en.file.Seek(-8, SeekOrigin.Current);
                    en.file.Write(buffer1, 0, 8);
                    en.file.Seek(old_name_len + 1, SeekOrigin.Current);
                }
            }
            else//需要在末尾追加目录项
            {
                if (en.current_inode > 0)//存在上一目录项
                    en.file.WriteByte(0);//跳过上一目录项末尾字节
            }
            byte[] buffer = new byte[req_len];
            Util.put_uint32(buffer, 0, inode);
            Util.put_uint16(buffer, 4, rec_len);
            Util.put_uint16(buffer, 6, (short)fname.Length);
            Array.Copy(fname, 0, buffer, 8, fname.Length);
            en.file.Write(buffer, 0, req_len);
            en.Dispose();
        }
        /// <summary>
        /// 删除一个目录项；对目录项对应的inode不作处理
        /// </summary>
        public void DeleteChild(int inode)
        {
            long previous_pos = -1;
            DirectoryEnumberator en = (DirectoryEnumberator)GetEnumerator();
            byte[] buffer = new byte[8];
            while (en.MoveNext())
            {
                if (en.current_inode == inode)//找到了要删除的inode
                {
                    //读取当前目录项长度
                    en.file.Position = en.entry_pos;
                    en.file.Read(buffer, 0, 8);
                    short rec_len = Util.get_uint16(buffer, 4);
                    short name_len = Util.get_uint16(buffer, 6);
                    if (previous_pos >= 0)//修改前面的目录项
                    {
                        rec_len += (short)(en.entry_pos - previous_pos);
                        Util.put_uint16(buffer, 4, rec_len);
                        en.file.Position = previous_pos + 4;
                        en.file.Write(buffer, 4, 2);
                    }
                    else if (en.entry_pos > 0)//修改开头的指针
                    {
                        rec_len += (short)en.entry_pos;
                        Util.put_uint32(buffer, 0, 0);
                        Util.put_uint16(buffer, 4, rec_len);
                        Util.put_uint16(buffer, 6, 0);
                        en.file.Position = 0;
                        en.file.Write(buffer, 0, 8);
                    }
                    else//要删除开头的目录项
                    {
                        Util.put_uint32(buffer, 0, 0);
                        Util.put_uint16(buffer, 6, 0);
                        en.file.Position = 0;
                        en.file.Write(buffer, 0, 8);
                    }
                    en.Dispose();
                    return;
                }
                previous_pos = en.entry_pos;
            }
            //目录项找不到
            throw new FileNotFoundException();
        }
        public class DirectoryEnumberator : IEnumerator<FileInfo>
        {
            internal File file;
            private string path;
            private System.Text.Encoding enc;
            internal int current_inode;
            internal string current_filename;
            internal long entry_pos;//当前目录项开始位置
            internal int next;//前往下一目录项需要后移的位置，为0时表示没有下一目录项
            public DirectoryEnumberator(Directory dir)
            {
                file = new File(dir.inode);
                path = dir.path;
                enc = new System.Text.ASCIIEncoding();
                this.Reset();
            }
            public FileInfo Current
            {
                get
                {
                    if (current_inode == 0) if (!MoveNext()) return null;
                    return new FileInfo(file.inode.fs, current_inode, (path + "/" + current_filename).Replace("//", "/"));
                }
            }
            public void Dispose()
            {
                file.Close();
            }
            object System.Collections.IEnumerator.Current
            {
                get { return Current; }
            }
            public bool MoveNext()
            {
                if (next < 0) return false;//上次已经读完
                if (file.Position + 8 > file.Length)//目录文件已经读完
                {
                    next = -1;
                    return false;
                }
                file.Seek(next, SeekOrigin.Current);
                entry_pos = file.Position;
                byte[] buffer = new byte[8];
                file.Read(buffer, 0, 8);
                int inode = Util.get_uint32(buffer, 0);
                if (inode == 0)//目录项无效，已经读完
                {
                    next = -1;
                    file.Seek(-8, SeekOrigin.Current);
                    return false;
                }
                short rec_len = Util.get_uint16(buffer, 4);
                int name_len = Util.get_uint16(buffer, 6);
                byte[] filename = new byte[name_len];
                file.Read(filename, 0, name_len);
                current_inode = inode;
                current_filename = enc.GetString(filename);
                next = rec_len - 8 - name_len;
                return true;
            }
            public void Reset()
            {
                file.Position = 0;
                current_inode = 0;
                current_filename = null;
                byte[] buffer = new byte[8];
                file.Read(buffer, 0, 8);
                int inode = Util.get_uint32(buffer, 0);
                short rec_len = Util.get_uint16(buffer, 4);
                if (inode > 0)//当前目录项有效
                {
                    next = 0;
                    file.Position = 0;
                }
                else if (rec_len > 0)//当前目录项无效，后面还有
                {
                    next = rec_len;
                    file.Position = 0;
                }
                else//无目录项
                {
                    next = -1;
                    file.Position = 0;
                }
            }
        }
    }
}