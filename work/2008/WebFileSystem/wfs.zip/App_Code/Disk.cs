﻿using System;
using System.IO;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 虚拟磁盘
    /// </summary>
    public class Disk
    {
        //基本信息
        private int sector_size_;
        public int sector_size { get { return sector_size_; } }
        private int sector_count_;
        public int sector_count { get { return sector_count_; } }

        //磁盘头相关定义
        public const int header_length = 32;
        public const int header_magic_length = 24;
        public static byte[] header_magic { get { return new byte[] { 0x49, 0x44, 0x43, 0x76, 0x66, 0x73, 0x44, 0x69, 0x73, 0x6B, 0x00, 0x77, 0x77, 0x77, 0x2E, 0x36, 0x35, 0x35, 0x33, 0x36, 0x2E, 0x63, 0x6E, 0x01 }; } }

        internal FileStream file;
        private Disk() { }
        /// <summary>
        /// 打开现有虚拟磁盘
        /// </summary>
        public Disk(string host_filename)
        {
            file = new FileStream(host_filename, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            byte[] header = new byte[header_length];
            file.Read(header, 0, header_length);
            if (!Util.byte_array_compare(header, 0, header_magic, 0, header_magic_length)) throw new InvalidHostFileException();
            sector_size_ = Util.get_uint32(header, header_magic_length);
            sector_count_ = Util.get_uint32(header, header_magic_length + 4);
        }
        /// <summary>
        /// 关闭虚拟磁盘
        /// </summary>
        public void Close()
        {
            file.Close();
            file.Dispose();
        }
        /// <summary>
        /// 创建新的虚拟磁盘
        /// </summary>
        public static Disk Create(string host_filename, int sector_size, int sector_count)
        {
            FileStream file = new FileStream(host_filename, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
            byte[] header = new byte[header_length];
            Array.Copy(header_magic, header, header_magic_length);
            Util.put_uint32(header, header_magic_length, sector_size);
            Util.put_uint32(header, header_magic_length + 4, sector_count);
            file.Write(header, 0, header_length);
            byte[] sector_zero = new byte[sector_size];
            for (int i = 0; i < sector_count; ++i) file.Write(sector_zero, 0, sector_size);
            Disk disk = new Disk();
            disk.file = file;
            disk.sector_size_ = sector_size;
            disk.sector_count_ = sector_count;
            return disk;
        }

        /// <summary>
        /// 读取一个sector
        /// </summary>
        public void Read(int sector, byte[] buffer, int start)
        {
            if (sector < 0 || sector >= sector_count_) throw new SectorNotFoundException();
            file.Seek(header_length + sector * sector_size_, SeekOrigin.Begin);
            file.Read(buffer, start, sector_size_);
        }
        /// <summary>
        /// 写入一个sector
        /// </summary>
        public void Write(int sector, byte[] buffer, int start)
        {
            if (sector < 0 || sector >= sector_count_) throw new SectorNotFoundException();
            file.Seek(header_length + sector * sector_size_, SeekOrigin.Begin);
            file.Write(buffer, start, sector_size_);
        }
        /// <summary>
        /// 宿主文件不是有效的虚拟磁盘
        /// </summary>
        public class InvalidHostFileException : Exception { }
        /// <summary>
        /// sector不存在
        /// </summary>
        public class SectorNotFoundException : Exception { }
    }
}