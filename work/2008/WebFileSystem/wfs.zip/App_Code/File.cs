﻿using System;
using System.IO;
using System.Collections.Generic;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 打开的文件流
    /// </summary>
    public class File : Stream
    {
        public const int data_size = 2000;//每sector保存的数据量
        public const int data_start = 48;//每sector数据开始位置
        internal inode inode;
        private int size { get { return inode.size; } set { inode.size = value; } }
        private FileSystem fs { get { return inode.fs; } }
        private Disk disk { get { return inode.fs.disk; } }
        private List<int> sectors;//文件对应的sector列表(包含前面已读到的部分)
        private int buffer_index;//被缓存的sector在文件中的排序
        private bool dirty;//当前buffer被写过
        private byte[] buffer;
        private int pos;
        private bool modified;

        internal File(inode inode)
        {
            this.Initialize(inode);
        }
        private void Initialize(inode inode)
        {
            this.inode = inode;
            this.pos = 0;
            this.sectors = new List<int>();
            this.buffer_index = -1;
            this.dirty = false;
            this.modified = false;
            this.buffer = new byte[FileSystem.sector_size];
        }
        public static File Open(inode inode)
        {
            if (inode.directory) throw new InvalidOperationException();
            return new File(inode);
        }
        public override void Close()
        {
            Flush();
            if (modified) inode.modified = DateTime.Now;
            inode.Put();
        }
        public override bool CanRead
        {
            get { return true; }
        }
        public override bool CanSeek
        {
            get { return true; }
        }
        public override bool CanWrite
        {
            get { return !inode.read_only; }
        }
        public override void Flush()
        {
            if (buffer_index < 0 || !dirty) return;
            modified = true;
            disk.Write(sectors[buffer_index], buffer, 0);
            dirty = false;
        }
        public override long Length
        {
            get { return size; }
        }
        public override long Position
        {
            get
            {
                return pos;
            }
            set
            {
                pos = (int)value;
                if (pos >= size) pos = size - 1;
                if (pos < 0) pos = 0;
            }
        }
        public override int Read(byte[] buffer, int offset, int count)
        {
            for (int i = 0, j = offset; i < count; ++i, ++j, ++pos)
            {
                try { buffer[j] = this[pos]; }
                catch (EndOfStreamException)
                {
                    return i;
                }
            }
            return count;
        }
        public override long Seek(long offset, SeekOrigin origin)
        {
            switch (origin)
            {
                case SeekOrigin.Begin: Position = offset; break;
                case SeekOrigin.Current: Position += offset; break;
                case SeekOrigin.End: Position = size + offset; break;
            }
            return this.Position;
        }
        public override void SetLength(long value)
        {
            int len = (int)value;
            if (len == size) return;
            if (inode.read_only) throw new InvalidOperationException();
            int index = len / data_size;//新的最后一个sector
            if (len > size)//增加空间
            {
                FindSector(index);//找到当前所有sector
                while (sectors.Count < index)//需要分配更多空间
                    AllocateNewSector();
            }
            if (len < size)//减少空间
            {
                while (FindSector(sectors.Count) > 0) ;//找到所有sector
                if (index < sectors.Count - 1)//需要删除后续sector
                {
                    LoadSector(index);
                    Util.put_uint32(buffer, 12, 0);
                    dirty = true;
                    for (int i = index + 1; i < sectors.Count; ++i)
                    {
                        fs.bitmap[sectors[i]] = false;
                        --fs.size_data_used_;
                    }
                }
            }
            size = len;
        }
        public override void Write(byte[] buffer, int offset, int count)
        {
            for (int i = 0, j = offset; i < count; ++i, ++j, ++pos)
            {
                this[pos] = buffer[j];
            }
        }
        public byte this[int i]
        {
            get
            {
                if (i >= size) throw new EndOfStreamException();
                BufferTo(i);
                return buffer[data_start + i % data_size];
            }
            set
            {
                if (inode.read_only) throw new InvalidOperationException();
                BufferTo(i);
                buffer[data_start + i % data_size] = value;
                dirty = true;
                if (i >= size) size = i + 1;
            }
        }
        /// <summary>
        /// 使pos这个位置进入buffer
        /// </summary>
        private void BufferTo(int pos)
        {
            int index = pos / data_size;//要前往的sector
            if (FindSector(index) == 0)
                while (sectors.Count <= index)//需要分配更多空间
                    AllocateNewSector();
            LoadSector(index);
            //读写指针不在此处修改
        }
        /// <summary>
        /// 将本文件的指定sector读入缓存，要求已知其sector号
        /// </summary>
        private void LoadSector(int index)
        {
            if (buffer_index == index) return;
            Flush();
            disk.Read(sectors[index], buffer, 0);
            buffer_index = index;
        }
        /// <summary>
        /// 在当前最后sector后面分配新的sector，保留在缓存中
        /// </summary>
        private int AllocateNewSector()
        {
            if (inode.read_only) throw new InvalidOperationException();
            //找到当前文件的所有sector
            while (FindSector(sectors.Count) > 0) ;
            //分配新sector
            int new_sector = fs.allocator.AllocateDataSector();
            if (new_sector < 0) throw new IOException();//没有空闲空间
            fs.bitmap[new_sector] = true;
            ++fs.size_data_used_;
            int index = sectors.Count;
            int previous = sectors.Count > 0 ? sectors[index - 1] : 0;
            int next = 0;
            if (index > 0)
            {
                LoadSector(sectors.Count - 1);
                Util.put_uint32(buffer, 12, new_sector);
                dirty = true;
                Flush();
            }
            else//分配文件的第一个sector
            {
                inode.content = new_sector;
            }
            sectors.Add(new_sector);
            //准备新sector内容
            buffer_index = index;
            Util.put_uint32(buffer, 0, inode.id);
            Util.put_uint32(buffer, 4, index);
            Util.put_uint32(buffer, 8, previous);
            Util.put_uint32(buffer, 12, next);
            Array.Clear(buffer, data_start, data_size);
            dirty = true;
            return index;
        }
        /// <summary>
        /// 寻找当前文件的第index个sector号；若已经找到最后一个sector还没找到，返回0
        /// </summary>
        private int FindSector(int index)
        {
            while (sectors.Count <= index)
            {
                if (sectors.Count > 0)
                {
                    LoadSector(sectors.Count - 1);
                    int next = Util.get_uint32(buffer, 12);
                    if (next == 0) return 0;
                    else sectors.Add(next);
                }
                else
                {
                    if (inode.content > 0) sectors.Add(inode.content);
                    else return 0;
                }
            }
            return sectors[index];
        }
    }
}