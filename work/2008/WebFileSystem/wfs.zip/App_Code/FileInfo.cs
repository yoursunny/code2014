﻿using System;
using System.IO;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 文件信息
    /// </summary>
    public class FileInfo : inode
    {
        private string filename;
        public FileInfo(FileSystem fs, int inode_id, string pathname)
            : base(fs, inode_id)
        {
            filename = pathname;
        }
        /// <summary>
        /// 不含路径的文件名
        /// </summary>
        public string FileName
        {
            get
            {
                string[] path_segments = filename.Split('/');
                return path_segments[path_segments.Length - 1];
            }
        }
        /// <summary>
        /// 完整的文件名
        /// </summary>
        public string PathName
        {
            get
            {
                return filename;
            }
        }
        /// <summary>
        /// 打开文件
        /// </summary>
        public File Open()
        {
            return File.Open(this);
        }
        /// <summary>
        /// 删除文件
        /// </summary>
        public override void Delete()
        {
            Delete(false);
        }
        /// <summary>
        /// 删除文件或目录
        /// </summary>
        public void Delete(bool recursive)
        {
            Delete(recursive, parent);
        }
        /// <summary>
        /// 删除文件或目录
        /// </summary>
        /// <param name="parent">父目录inode号；为-1时不处理目录项</param>
        private void Delete(bool recursive, int parent)
        {
            if (id_ == 0)//根目录不能删除
                throw new InvalidOperationException();
            if (directory)//删除目录
            {
                System.Collections.Generic.IEnumerator<FileInfo> en = new Directory(this, filename).GetEnumerator();
                if (recursive)
                {
                    while (en.MoveNext())
                    {
                        en.Current.Delete(true, -1);
                    }
                }
                else if (en.MoveNext())//非递归删除，而目录非空
                    throw new InvalidOperationException();
                en.Dispose();
            }
            if (parent >= 0)
            {
                Directory p = new Directory(new inode(fs, parent), "");//不需要读取文件名，随意设置路径值
                p.DeleteChild(id_);
            }
            base.Delete();//删除文件内容和inode
        }
    }
}