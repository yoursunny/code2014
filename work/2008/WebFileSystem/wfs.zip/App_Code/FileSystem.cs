﻿using System;
using System.IO;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 文件系统
    /// </summary>
    public class FileSystem
    {
        //基本统计信息
        private int size_; public int size { get { return size_; } }
        private int size_bitmap_; public int size_bitmap { get { return size_bitmap_; } }
        private int size_inode_; public int size_inode { get { return size_inode_; } }
        private int size_inode_bitmap_; public int size_inode_bitmap { get { return size_inode_bitmap_; } }
        public int size_data { get { return size_ - start_data; } }
        private int count_inode_; public int count_inode { get { return count_inode_; } }
        internal int count_inode_used_; public int count_inode_used { get { return count_inode_used_; } }
        internal int size_data_used_; public int size_data_used { get { return size_data_used_; } }

        //sector位置计算
        internal int start_header { get { return 0; } }
        internal int start_bitmap { get { return 1; } }
        internal int start_inodes { get { return 1 + size_bitmap_; } }
        internal int start_inode_bitmap { get { return start_inodes + size_inode_; } }
        internal int start_data { get { return start_inode_bitmap + size_inode_bitmap_; } }

        internal Disk disk;
        //缓存
        internal byte[] header;
        internal Bitmap bitmap;
        internal byte[] inodes;
        internal Bitmap inode_bitmap;

        //空间分配算法
        internal IAllocator allocator;

        public const int sector_size = 2048;
        internal static byte[] header_magic = new byte[] { 0x49, 0x44, 0x43, 0x76, 0x66, 0x73, 0x00, 0x01 };
        internal const int header_magic_size = 8;
        /// <summary>
        /// 打开文件系统
        /// </summary>
        public FileSystem(string host_filename)
        {
            disk = new Disk(host_filename);
            if (disk.sector_size != sector_size) throw new InvalidFileSystemException();
            header = new byte[sector_size];
            disk.Read(start_header, header, 0);
            if (!Util.byte_array_compare(header, 0, header_magic, 0, header_magic_size)) throw new InvalidFileSystemException();
            size_ = Util.get_uint32(header, 8);
            size_bitmap_ = Util.get_uint32(header, 12);
            size_inode_ = Util.get_uint32(header, 16);
            size_inode_bitmap_ = Util.get_uint32(header, 20);
            count_inode_ = Util.get_uint32(header, 24);
            count_inode_used_ = Util.get_uint32(header, 28);
            size_data_used_ = Util.get_uint32(header, 32);
            PrepareCaches(true);
        }
        private FileSystem() { }
        /// <summary>
        /// 关闭文件系统
        /// </summary>
        public void Close()
        {
            SaveHeader();
            SaveCaches();
            disk.Close();
        }
        /// <summary>
        /// 创建文件系统
        /// </summary>
        /// <param name="inode_sector_count">inode区sector数，取sector_count/4096可支持平均128kb文件大小</param>
        public static FileSystem Create(string host_filename, int sector_count, int inode_sector_count)
        {
            if (sector_count < 5 || sector_count > 1048576) throw new ArgumentOutOfRangeException("sector_count");
            if (inode_sector_count < 0 || inode_sector_count > sector_count - 4) throw new ArgumentOutOfRangeException("inode_sector_count");
            FileSystem fs = new FileSystem();
            fs.disk = Disk.Create(host_filename, sector_size, sector_count);
            //准备磁盘头
            fs.header = new byte[sector_size];
            fs.size_ = sector_count;
            fs.size_bitmap_ = Util.div_ceil(fs.size_, 8 * 2048);
            fs.size_inode_ = inode_sector_count;
            fs.size_inode_bitmap_ = Util.div_ceil(fs.size_inode_, 8 * 2048 / 64);
            fs.count_inode_ = fs.size_inode_ * 64;
            fs.count_inode_used_ = 0;
            fs.size_data_used_ = 0;
            fs.SaveHeader();
            //准备bitmap、inodes、inode_bitmap缓存
            fs.PrepareCaches(false);
            fs.bitmap.SetRange(0, fs.start_data, true);//占据系统区域的sector
            //创建根目录
            inode root = new inode(fs);
            root.id_ = 0;
            root.directory = true;
            root.Put();
            return fs;
        }
        /// <summary>
        /// 准备bitmap、inodes、inode_bitmap缓存
        /// </summary>
        private void PrepareCaches(bool load)
        {
            bitmap = new Bitmap(); bitmap.bytes = new byte[size_bitmap_ * sector_size];
            inodes = new byte[size_inode_ * sector_size];
            inode_bitmap = new Bitmap(); inode_bitmap.bytes = new byte[size_inode_bitmap_ * sector_size];
            if (load)
            {
                for (int end = start_bitmap + size_bitmap_, i = start_bitmap, j = 0; i < end; ++i, j += sector_size)
                    disk.Read(i, bitmap.bytes, j);
                for (int end = start_inodes + size_inode_, i = start_inodes, j = 0; i < end; ++i, j += sector_size)
                    disk.Read(i, inodes, j);
                for (int end = start_inode_bitmap + size_inode_bitmap, i = start_inode_bitmap, j = 0; i < end; ++i, j += sector_size)
                    disk.Read(i, inode_bitmap.bytes, j);
            }
            allocator = new LargestBlockAllocator(this);
        }
        /// <summary>
        /// 更新header并写入磁盘
        /// </summary>
        internal void SaveHeader()
        {
            Array.Copy(header_magic, header, header_magic_size);
            Util.put_uint32(header, 8, size_);
            Util.put_uint32(header, 12, size_bitmap_);
            Util.put_uint32(header, 16, size_inode_);
            Util.put_uint32(header, 20, size_inode_bitmap_);
            Util.put_uint32(header, 24, count_inode_);
            Util.put_uint32(header, 28, count_inode_used_);
            Util.put_uint32(header, 32, size_data_used_);
            disk.Write(start_header, header, 0);
        }
        /// <summary>
        /// 将bitmap、inodes、inode_bitmap缓存写入磁盘
        /// </summary>
        internal void SaveCaches()
        {
            for (int end = start_bitmap + size_bitmap_, i = start_bitmap, j = 0; i < end; ++i, j += sector_size)
                disk.Write(i, bitmap.bytes, j);
            for (int end = start_inodes + size_inode_, i = start_inodes, j = 0; i < end; ++i, j += sector_size)
                disk.Write(i, inodes, j);
            for (int end = start_inode_bitmap + size_inode_bitmap, i = start_inode_bitmap, j = 0; i < end; ++i, j += sector_size)
                disk.Write(i, inode_bitmap.bytes, j);
        }
        /// <summary>
        /// 获取文件信息
        /// </summary>
        public FileInfo GetFile(string path)
        {
            return new FileInfo(this, inode.Find(this, path).id, path);
        }
        /// <summary>
        /// 判定文件是否存在
        /// </summary>
        public bool FileExists(string path)
        {
            try { inode.Find(this, path); return true; }
            catch { return false; }
        }
        /// <summary>
        /// 打开文件
        /// </summary>
        public File OpenFile(string path)
        {
            inode inode = inode.FindOrCreate(this, path, false);
            return File.Open(inode);
        }
        /// <summary>
        /// 读取文件的全部内容
        /// </summary>
        public string ReadAllText(string path, System.Text.Encoding enc)
        {
            StreamReader r = new StreamReader(OpenFile(path), enc);
            string s = r.ReadToEnd();
            r.Close();
            return s;
        }
        /// <summary>
        /// 读取文件的全部内容，UTF-8
        /// </summary>
        public string ReadAllText(string path)
        {
            return ReadAllText(path, System.Text.Encoding.UTF8);
        }
        /// <summary>
        /// 写入文件的全部内容
        /// </summary>
        public void WriteAllText(string path, string content, System.Text.Encoding enc)
        {
            StreamWriter w = new StreamWriter(OpenFile(path), enc);
            w.Write(content);
            w.Close();
        }
        /// <summary>
        /// 写入文件的全部内容，UTF8
        /// </summary>
        public void WriteAllText(string path, string content)
        {
            WriteAllText(path, content, System.Text.Encoding.UTF8);
        }
        /// <summary>
        /// 读取目录列表
        /// </summary>
        public FileInfo[] ReadDirectory(string path)
        {
            inode inode = inode.Find(this, path);
            Directory d = new Directory(inode, path);
            System.Collections.Generic.List<FileInfo> r = new System.Collections.Generic.List<FileInfo>();
            foreach (FileInfo f in d) r.Add(f);
            return r.ToArray();
        }
        /// <summary>
        /// 删除文件或目录
        /// </summary>
        public void DeleteFile(string file, bool recursive)
        {
            new FileInfo(this, inode.Find(this, file).id_, file).Delete(recursive);
        }
        /// <summary>
        /// 无效的文件系统
        /// </summary>
        public class InvalidFileSystemException : Exception { }
    }
}