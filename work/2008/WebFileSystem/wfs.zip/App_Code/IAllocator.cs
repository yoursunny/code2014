﻿using System;
using System.IO;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 空间分配器
    /// </summary>
    public interface IAllocator
    {
        int AllocateDataSector();
    }
}