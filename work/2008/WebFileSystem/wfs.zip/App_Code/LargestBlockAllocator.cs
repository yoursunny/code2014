﻿using System;
using System.IO;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 分配最大空闲块的开始sector
    /// </summary>
    public class LargestBlockAllocator : IAllocator
    {
        FileSystem fs;
        public LargestBlockAllocator(FileSystem fs)
        {
            this.fs = fs;
        }
        public int AllocateDataSector()
        {
            if (fs.size_data_used == fs.size_data) return -1;//没有空闲空间
            int largest_block_size = 0;
            int largest_block_start = -1;
            int this_block_start = -1;
            bool previous = true;//上一块是否占用
            for (int i = fs.start_data; i < fs.size; ++i)
            {
                bool occupy = fs.bitmap[i];
                if (previous && !occupy)//发现空闲块的开始
                    this_block_start = i;
                if (!previous && occupy)//上一sector是空闲块的结束
                {
                    int this_block_size = i - this_block_start;
                    if (largest_block_size < this_block_size)//发现更大的空闲块
                    {
                        largest_block_start = this_block_start;
                        largest_block_size = this_block_size;
                    }
                }
                previous = occupy;
            }
            if (!previous)//最后一个sector空闲，判断最后一块是否是最大空闲块
            {
                int this_block_size = fs.size - this_block_start;
                if (largest_block_size < this_block_size)//发现更大的空闲块
                {
                    largest_block_start = this_block_start;
                    largest_block_size = this_block_size;
                }
            }
            //只负责指定分配的sector号，不修改bitmap和统计信息
            return largest_block_start;
        }
    }
}