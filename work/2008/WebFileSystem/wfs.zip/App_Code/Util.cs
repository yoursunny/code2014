﻿using System;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 辅助工具
    /// </summary>
    public static class Util
    {
        /// <summary>
        /// 读取big endian的32位无符号整数
        /// </summary>
        public static int get_uint32(byte[] buffer, int start)
        {
            UInt32 value = 0;
            for (int i = 0; i < 4; ++i)
            {
                value *= 256;
                value += buffer[start + i];
            }
            return (int)value;
        }
        /// <summary>
        /// 写入big endian的32位无符号整数
        /// </summary>
        public static void put_uint32(byte[] buffer, int start, int value)
        {
            UInt32 v = (UInt32)value;
            for (int i = 3; i >= 0; --i)
            {
                buffer[start + i] = Convert.ToByte(v % 256);
                v /= 256;
            }
        }
        /// <summary>
        /// 读取big endian的16位无符号整数
        /// </summary>
        public static short get_uint16(byte[] buffer, int start)
        {
            UInt16 value = 0;
            for (int i = 0; i < 2; ++i)
            {
                value *= 256;
                value += buffer[start + i];
            }
            return (short)value;
        }
        /// <summary>
        /// 写入big endian的16位无符号整数
        /// </summary>
        public static void put_uint16(byte[] buffer, int start, short value)
        {
            UInt16 v = (UInt16)value;
            for (int i = 1; i >= 0; --i)
            {
                buffer[start + i] = Convert.ToByte(v % 256);
                v /= 256;
            }
        }
        /// <summary>
        /// 比较两个字节数组是否相等
        /// </summary>
        public static bool byte_array_compare(byte[] arr1, int start1, byte[] arr2, int start2, int length)
        {
            int end = start1 + length;
            for (int i = start1, j = start2; i < end; ++i, ++j) if (arr1[i] != arr2[j]) return false;
            return true;
        }
        /// <summary>
        /// ceil(a/b)
        /// </summary>
        public static int div_ceil(int a, int b)
        {
            return (a % b == 0) ? (a / b) : (a / b + 1);
        }
        private static DateTime unix_timestamp_zero { get { return new DateTime(1970, 1, 1); } }
        /// <summary>
        /// UNIX时间戳转成DateTime
        /// </summary>
        public static DateTime unix_timestamp(int u)
        {
            TimeSpan ts = new TimeSpan((long)u * 10000000);
            return unix_timestamp_zero + ts;
        }
        /// <summary>
        /// DateTime转成UNIX时间戳
        /// </summary>
        public static int unix_timestamp(DateTime u)
        {
            return Convert.ToInt32((u - unix_timestamp_zero).TotalSeconds);
        }
    }
}