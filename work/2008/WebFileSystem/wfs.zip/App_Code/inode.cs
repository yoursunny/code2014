﻿using System;
using System.IO;

namespace yoursunny.P2008.WebFileSystem
{
    /// <summary>
    /// 索引节点
    /// </summary>
    public class inode
    {
        public const int inode_size = 32;
        public const byte mask_directory = 0x01;
        public const byte mask_readonly = 0x02;

        internal int id_;
        public int id { get { return id_; } }
        internal FileSystem fs;
        //属性信息
        public int content;
        public int size;
        public int parent;
        public DateTime created;
        public DateTime modified;
        public bool directory;
        public bool read_only;
        
        /// <summary>
        /// 分配新的inode
        /// </summary>
        public inode(FileSystem fs)
        {
            this.fs = fs;
            id_ = -1;
            created = modified = DateTime.Now;
        }
        /// <summary>
        /// 根据编号获取inode
        /// </summary>
        public inode(FileSystem fs, int id)
        {
            if (!fs.inode_bitmap[id]) throw new FileNotFoundException();
            this.id_ = id;
            this.fs = fs;
            int offset = inode_size * id;
            content = Util.get_uint32(fs.inodes, offset);
            size = Util.get_uint32(fs.inodes, offset + 4);
            parent = Util.get_uint32(fs.inodes, offset + 8);
            created = Util.unix_timestamp(Util.get_uint32(fs.inodes, offset + 12));
            modified = Util.unix_timestamp(Util.get_uint32(fs.inodes, offset + 16));
            byte attributes = fs.inodes[offset + 20];
            directory = (attributes & mask_directory) > 0;
            read_only = (attributes & mask_readonly) > 0;
        }
        /// <summary>
        /// 根据路径获取inode
        /// </summary>
        public static inode Find(FileSystem fs, string path)
        {
            return Find(fs, path, false, false);
        }
        /// <summary>
        /// 根据路径获取或创建inode
        /// </summary>
        /// <param name="directory">如需创建，是否为目录</param>
        public static inode FindOrCreate(FileSystem fs, string path, bool directory)
        {
            return Find(fs, path, true, directory);
        }
        private static inode Find(FileSystem fs, string path, bool create, bool directory)
        {
            if (string.IsNullOrEmpty(path)) throw new ArgumentNullException("path");
            if (path[0] != '/') throw new ArgumentException();
            string[] path_segment = path.Remove(0, 1).Split('/');
            inode parent = new inode(fs, 0);
            if (path == "/") return parent;
            for (int i = 0; i < path_segment.Length; ++i)
            {
                Directory d = new Directory(parent, "/" + string.Join("/", path_segment, 0, i));
                inode child = null;
                foreach (FileInfo f in d)
                {
                    if (f.FileName == path_segment[i])
                    {
                        child = f;
                    }
                }
                if (child == null)
                {
                    if (create)
                    {
                        child = new inode(fs);
                        child.directory = (i + 1 < path_segment.Length) ? true : directory;
                        child.parent = parent.id_;
                        child.Put();
                        d.AddChild(child.id_, path_segment[i]);
                    }
                    else throw new FileNotFoundException();
                }
                parent = child;
            }
            return parent;
        }
        /// <summary>
        /// 分配一个空闲的inode号
        /// </summary>
        internal void AllocateID()
        {
            if (id_ >= 0) return;
            if (fs.count_inode == fs.count_inode_used) throw new inodeUsedUpException();
            for (int i = 0; i < fs.count_inode; ++i)
            {
                if (!fs.inode_bitmap[i]) { id_ = i; return; }
            }
        }
        /// <summary>
        /// 保存到cache
        /// </summary>
        public void Put()
        {
            if (id_ < 0) AllocateID();
            if (!fs.inode_bitmap[id_]) { ++fs.count_inode_used_; fs.inode_bitmap[id_] = true; }
            byte attribute = (byte)((directory ? mask_directory : (byte)0) + (read_only ? mask_readonly : (byte)0));
            int offset = inode_size * id_;
            Util.put_uint32(fs.inodes, offset, content);
            Util.put_uint32(fs.inodes, offset + 4, size);
            Util.put_uint32(fs.inodes, offset + 8, parent);
            Util.put_uint32(fs.inodes, offset + 12, Util.unix_timestamp(created));
            Util.put_uint32(fs.inodes, offset + 16, Util.unix_timestamp(modified));
            fs.inodes[offset + 20] = attribute;
        }
        /// <summary>
        /// 删除这个inode及对应文件；对目录文件，不处理目录内数据
        /// </summary>
        public virtual void Delete()
        {
            if (id_ < 0) return;
            if (fs.inode_bitmap[id_]) { --fs.count_inode_used_; fs.inode_bitmap[id_] = false; }
            id_ = -1;
            if (content > 0)//删除文件数据
            {
                int sector = content;
                byte[] buffer = new byte[FileSystem.sector_size];
                while (sector > 0)
                {
                    fs.disk.Read(sector, buffer, 0);
                    fs.bitmap[sector] = false;
                    --fs.size_data_used_;
                    sector = Util.get_uint32(buffer, 12);
                }
            }
        }
        /// <summary>
        /// inode全部用完
        /// </summary>
        public class inodeUsedUpException : Exception { }
    }
}