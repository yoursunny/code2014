<?php
set_time_limit(300);
$time_start=time();
header('Content-Type: text/plain');
$tar=fopen(__FILE__,'rb');
fseek($tar,__COMPILER_HALT_OFFSET__);
$gzh=fread($tar,10);
$gzf=ord($gzh{3});//FLG
if ($gzf & 0x04) {//FEXTRA
	$gz_xlen=fread($tar,2);
	$gz_xlen=ord($gz_xlen{0})<<8+ord($gz_xlen{1});
	fseek($tar,$gz_xlen,SEEK_CUR);
}
if ($gzf & 0x08) {//FNAME
	while (0!=ord(fgetc($tar)));
}
if ($gzf & 0x10) {//FCOMMENT
	while (0!=ord(fgetc($tar)));
}
if ($gzf & 0x02) {//FHCRC
	fseek($tar,2,SEEK_CUR);
}
stream_filter_append($tar,'zlib.inflate');
$archive_end=str_repeat('\0',512);
$n=-1;
echo 'yoursunny webtar'."\r\n".'http://www.65536.cn/work/2008/WebTar/';
while (TRUE) {
	$header=fread($tar,512);
	if ($header===FALSE || $header=='' || $header==$archive_end) break;
	if (++$n % 20 == 0) { if ($n%1000==0) echo "\r\n".'untar'; echo '.'; flush(); }
	$fname=substr($header,0,100);
	$fname=substr($fname,0,strpos($fname,chr(0)));
	if ($fname=='') break;
	$fname='./'.$fname;
	$fsize=octdec(substr($header,124,12));
	$is_dir=($header{156}=='5');
	$blocks=ceil($fsize/512);
	$last_block_size=$fsize%512;
	$last_block=$last_block_size==0?$blocks:$blocks-1;
	if ($is_dir) {
		if (!file_exists($fname)) mkdir($fname,0777,TRUE);
		for ($i=0;$i<$blocks;++$i) {
			fread($tar,512);
		}
	} else {
		$dir=dirname($fname);
		if (!file_exists($dir)) mkdir($dir,0777,TRUE);
		$o=fopen($fname,'wb');
		for ($i=0;$i<$blocks;++$i) {
			if ($i<$last_block) fwrite($o,fread($tar,512),512);
			else {
				fwrite($o,substr(fread($tar,512),0,$last_block_size));
			}
		}
		fclose($o);
	}
}
echo "\r\n".'done, '.$n.' entries, '.(time()-$time_start).' seconds taken';
fclose($tar);
unlink(__FILE__);
__halt_compiler();