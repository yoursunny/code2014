﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace yoursunny.P2008.hProxyN
{
    /// <summary>
    /// hProxyN element
    /// </summary>
    public class hProxyNConfigurationSectionGroup : ConfigurationSectionGroup
    {
    }
    /// <summary>
    /// PluginConfiguration element
    /// </summary>
    public class PluginConfigurationSectionGroup : ConfigurationSectionGroup
    {
    }
}
