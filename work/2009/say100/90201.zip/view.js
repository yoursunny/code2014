google.load('language','1');
google.setOnLoadCallback(function(){
	var query=location.href.toQueryParams();
	var w=query.w;
	if (!w || w=='') return;
	var container=$(document.body);
	var dimensions=document.viewport.getDimensions();
	container.setStyle({background:'#102439',position:'relative',fontSize:'9px',width:''+dimensions.width+'px',height:''+dimensions.height+'px'});
	function pickColor() {
		var colors=['#d6d7d6','#7b3c4a','#efdf29','#dec37b'];
		return colors[(Math.random()*colors.length).floor()];
	}
	var pos=[];
	function isInside(rect,x,y) {
		return (rect.left<=x) && (rect.right>=x) && (rect.top<=y) && (rect.bottom>=y);
	}
	function CountOverlaps(r) {
		var overlap=0;
		pos.each(function(rect){
			if (isInside(rect,r.left,r.top) || isInside(rect,r.right,r.top) || isInside(rect,r.left,r.bottom) || isInside(rect,r.right,r.bottom)) ++overlap;
		});
		return overlap;
	}
	function pickPosition(width,height) {
		var s=$R(0,20).collect(function() {
			var p={left:(Math.random()*(dimensions.width-width)).floor(),top:(Math.random()*(dimensions.height-height)).floor()};
			var rect={top:p.top,right:p.left+width,bottom:p.top+height,left:p.left};
			var overlap=CountOverlaps(rect);
			return [p,rect,overlap];
		}).sortBy(function(e){return e[2]}).first();
		pos.push(s[1]);
		return s[0];
	}
	Object.keys(google.language.Languages).each(function(lang){
		var langCode=google.language.Languages[lang];
		if (google.language.isTranslatable(langCode)) {
			google.language.translate(w,'',langCode,function(result){
				var d=$(document.createElement('div'));
				d.update(result.translation).setStyle({color:pickColor(),position:'absolute'}).writeAttribute('title',lang);
				container.appendChild(d);
				(function(){
					var size=d.getDimensions();
					var p=pickPosition(size.width,size.height);
					d.setStyle({left:''+p.left+'px',top:''+p.top+'px'});
				}).defer();
			});
		}
	});
});
