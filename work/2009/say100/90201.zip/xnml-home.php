<p><img src="http://i44.tinypic.com/2urvwb6.gif" width="468" height="60" alt="用100种语言说"/></p>
<?php
show_f_post();
?>
<p style="font-size:13pt;">快速体验：
<?php
function demo($w) {
	echo '<a href="'.APP_CANVAS.'/post?w='.urlencode($w).'">'.htmlspecialchars($w).'</a> &nbsp;&nbsp;'."\r\n";
}
demo('我爱你');
demo('你好');
demo('Cheer Up');
demo('我请你吃饭');
?>
</p>
<hr/>
<p style="font-size:12pt;line-height:18pt;">你可以用任何语言说一句话填写在上面。“用100种语言说”将把这句话翻译成各国语言，并以“通知”的形式发送给你选择的好友。</p>
<?php
appstat('home');
?>