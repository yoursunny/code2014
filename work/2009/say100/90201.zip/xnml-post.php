<?php
$w=''.@$_POST['w'];
if ($w=='') redirect();
$wh=htmlspecialchars($w);
?>
<form id="f_send" action="send" method="post"><div>
<p style="font-size:16pt;">我要用<span style="color:#f63;">100</span>种语言说
<span style="color:#33c;"><?php echo $wh; ?></span> <span style="font-size:12pt"><a href="<?php echo APP_CANVAS; ?>">修改</a></span></p>
<xn:iframe src="<?php echo APP_SERVER; ?>/view.htm?w=<?php echo $wh; ?>" width="640" height="300" addxnsig="false" frameborder="0" scrolling="no"/>
<hr/>
<p style="font-size:16pt;">把这句话发送给谁呢？</p>
<input type="hidden" name="w" value="<?php echo $wh; ?>"/>
<div style="line-height:100%;"><xn:multi-friend-selector max="3" include_me="true"/></div>
<input type="submit" value="发送" style="height:20pt;font-size:13pt;"/>
</div></form>
<?php
appstat('post');
?>