<?php
$w=''.@$_POST['w'];
if ($w=='') redirect();
if (!isset($_POST['ids'])) {
	redirect('/post?w='.urlencode($w));
}
$wh=htmlspecialchars($w);
$uid=$_POST['xn_sig_user'];
$ids=$_POST['ids'];
if (!is_array($ids)) $ids=array($ids);
$to_ids=implode(',',$ids);
$notification='<xn:name uid="'.$uid.'" linked="true" shownetwork="true"/>用100种语言对你说了一句话，<a href="'.APP_CANVAS.'/view?w='.urlencode($w).'&u='.$uid.'">点击查看</a>';
xiaonei_api('xiaonei.notifications.send',array('to_ids'=>$to_ids,'notification'=>$notification));
?>
<p><img src="http://i44.tinypic.com/2urvwb6.gif" width="468" height="60" alt="用100种语言说"/></p>
<p><span style="font-size:16pt;"><span style="color:#f00;">消息已发送。</span>
<a href="<?php echo APP_CANVAS ?>">再来一条</a></span></p>
<br/>
注：每天你只能发送8条消息，超过限额后好友将不能收到。
<?php
appstat('send');
?>