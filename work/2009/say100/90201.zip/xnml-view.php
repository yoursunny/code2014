<?php
$w=''.@$_POST['w'];
$u=''.@$_POST['u'];
if ($w=='' || $u=='' || !ctype_digit($u)) redirect();
$wh=htmlspecialchars($w);
?>
<xn:profile-pic uid="<?php echo $u; ?>" linked="false" size="normal"/><br/>
<p style="font-size:16pt;"><b><xn:name uid="<?php echo $u; ?>" linked="true" shownetwork="true"/></b>
用<span style="color:#f63;">100</span>种语言对你说——</p>
<xn:iframe src="<?php echo APP_SERVER; ?>/view.htm?w=<?php echo $wh; ?>" width="640" height="500" addxnsig="false" frameborder="0" scrolling="no"/>
<hr/>
<?php
show_f_post($w);
?>