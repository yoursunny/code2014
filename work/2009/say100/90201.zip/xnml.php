<?php
require_once $_SERVER["DOCUMENT_ROOT"].'/lib/9.php';
load_xiaonei();
//ob_start();
//phpinfo(INFO_VARIABLES);
//file_put_contents('phpinfo.htm',ob_get_clean());
define('APP_CANVAS','http://apps.xiaonei.com/say-it-to');
define('APP_ALIAS','say-it-to');
define('APP_SERVER','http://www.65536.cn/work/2009/say100');
$session_key=$_POST['xn_sig_session_key'];
define('xiaonei_APPID','4cfed29884da4864a74ce38c19cc1a41');
define('xiaonei_SECRET','37b35e24348346179a6a4e5e2f0c6505');

function show_f_post($v='') {
$f=<<<EOT
<form id="f_post" action="post" method="post"><div>
<span style="font-size:16pt;">我要用<span style="color:#f63;">100</span>种语言说——</span>
<input type="text" name="w" value="#value#" style="width:260pt;height:20pt;font-size:16pt;color:#33c;"/>
<input type="submit" value="继续" style="height:20pt;font-size:13pt;"/>
</div></form>
EOT;
	echo str_replace('#value#',htmlspecialchars($v),$f);
}
function redirect($u='') {
	ob_end_clean();
	echo '<xn:redirect url="'.APP_CANVAS.$u.'"/>';
	exit;
}
function appstat($k) {
	echo '<xn:iframe src="'.APP_SERVER.'/xiaonei.htm?'.$k.'" width="1" height="1" addxnsig="false" frameborder="0" scrolling="no"/>';
}

ob_start();
switch (''.@$_SERVER['PATH_INFO']) {
	case '/view':
		include 'xnml-view.php';
		break;
	case '':
		include 'xnml-home.php';
		break;
	case '/post':
		include 'xnml-post.php';
		break;
	case '/send':
		include 'xnml-send.php';
		break;
	default:
		redirect();
		break;
}
$xnml=ob_get_clean();
echo '<xn:title text="用100种语言说"/>'."\r\n";
echo '<div style="width:700px;min-height:400px;padding:30px;line-height:30pt;">'."\r\n";
echo $xnml;
echo "\r\n".'</div>';
?>