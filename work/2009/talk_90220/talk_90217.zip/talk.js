function talk_init(container,config) {
	var u=[];
	for (var p in config) {
		u.push(p+'='+encodeURIComponent(config[p]));
	}
	var d=document.createElement('iframe');
	d.src='http://65536.sunny/work/2009/talk/talk.htm#'+u.join('&');
	d.width=240;
	d.height=600;
	d.frameBorder=0;
	d.scrolling='no';
	document.getElementById(container).appendChild(d);
}