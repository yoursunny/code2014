<?php
/*
livetalk API接口

公共参数
cb=回调函数

查询本人信息 ?a=me
  callback({uid:本地用户名,nick:名字,u:name@domain或null,photo:照片URL} 或 null)

创建帐号预备 ?a=create
  callback({u:name@domain,v:验证串} 或 null)
创建帐号 https创建帐号接口?appid=appid&u=name@domain&p=password&v=验证串
  callback(OK|INVALID-HASH|SERVICE-ERROR)

绑定帐号到本人用户名 ?a=bind&u=name@domain
  callback({result:true})

查询联系人信息 ?a=contact&u=name@domain
  callback({uid:本地用户名,nick:名字,u:name@domain,photo:照片URL} 或 null)
查询用户信息 ?a=user&u=本地用户名
  callback({uid:本地用户名,nick:名字,u:name@domain或null,photo:照片URL} 或 null)

查询好友列表 ?a=friends
  callback({uid1:{uid:..,nick:..,u:..,photo:..},uid2:{uid:..,nick:..,u:..,photo:..},...只返回有聊天帐号的好友})

*/
$data=json_decode(file_get_contents('talk.json'),TRUE);
$o=NULL;
$uid=@$_COOKIE['talkdemo-user'];
switch ($_GET['a']) {
	case 'set'://for demo
		setcookie('talkdemo-user',$_GET['uid']);
		echo 'user set in cookie'; exit;
		break;
	case 'me':
		$o=@$data[$uid];
		if ($o==NULL) $o=array('uid'=>$uid,'nick'=>$uid,'u'=>NULL,'photo'=>'http://your9.sunny/images/photo.jpg');
		$data[$uid]=$o;
		break;
	case 'create':
		$d=$data[$uid];
		if ($d!=NULL) $o=array('register'=>'http://localhost:8080/work/2009/talk/AccountCreate','u'=>$uid.'@msgr.yoursunny.com','v'=>sha1($uid.'@msgr.yoursunny.com'.'{6EDBB115-DAD0-470b-9BA5-2FD704A3D093}'));
		break;
	case 'bind':
		$d=$data[$uid];
		if ($d==NULL) $o=array('result'=>FALSE);
		else { $o=array('result'=>TRUE); $data[$uid]['u']=$_GET['u']; }
		break;
	case 'contact':
		$u=$_GET['u'];
		foreach ($data as $d) {
			if ($d['u']==$u) { $o=$d; break; }
		}
		break;
	case 'user':
		$o=$_GET['u'];
		break;
	case 'friends':
		$o=$data;
		break;
}
echo @$_GET['cb'].'(('.json_encode($o).'));';
file_put_contents('talk.json',json_encode($data));
?>